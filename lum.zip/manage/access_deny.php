<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>DENIED</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<meta http-equiv="refresh" content="2; URL=./index.html">
<link href="Sans.css" rel="stylesheet" type="text/css">
<link href="access_deny.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="space"><br></div>
<div id="container">
<div id="wb_Image1" style="position:absolute;left:406px;top:310px;width:128px;height:128px;z-index:0;">
<img src="images/cancel-1.png" id="Image1" alt=""></div>
<div id="wb_Text1" style="position:absolute;left:350px;top:459px;width:250px;height:24px;text-align:center;z-index:1;">
<span style="color:#000000;font-family:Arial;font-size:20px;"><strong>ACCESS DENIED</strong></span></div>
</div>
</body>
</html>