<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>activation</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<meta http-equiv="refresh" content="2; URL=./admin.php">
<link href="Sans.css" rel="stylesheet" type="text/css">
<link href="act=ok.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="space"><br></div>
<div id="container">
<div id="wb_Text1" style="position:absolute;left:318px;top:163px;width:334px;height:69px;z-index:0;text-align:left;">
<span style="color:#CF002A;font-family:Arial;font-size:20px;">La creation du compte bancaire à été effectuer avec success un email a été envoyer au client</span></div>
<div id="wb_Image1" style="position:absolute;left:241px;top:168px;width:64px;height:64px;z-index:1;">
<img src="images/information.png" id="Image1" alt=""></div>
</div>
</body>
</html>