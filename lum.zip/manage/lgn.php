<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['form_name'] == 'loginform')
{
   $success_page = './lgn=ok.php';
   $error_page = './lgn=false.php';
   $database = './usersdb.php';
   $crypt_pass = md5($_POST['password']);
   $found = false;
   $fullname = '';
   $session_timeout = 600;
   if(filesize($database) > 0)
   {
      $items = file($database, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
      foreach($items as $line)
      {
         list($username, $password, $email, $name, $active) = explode('|', trim($line));
         if ($username == $_POST['username'] && $active != "0" && $password == $crypt_pass)
         {
            $found = true;
            $fullname = $name;
         }
      }
   }
   if($found == false)
   {
      header('Location: '.$error_page);
      exit;
   }
   else
   {
      if (session_id() == "")
      {
         session_start();
      }
      $_SESSION['username'] = $_POST['username'];
      $_SESSION['fullname'] = $fullname;
      $_SESSION['expires_by'] = time() + $session_timeout;
      $_SESSION['expires_timeout'] = $session_timeout;
      $rememberme = isset($_POST['rememberme']) ? true : false;
      if ($rememberme)
      {
         setcookie('username', $_POST['username'], time() + 3600*24*30);
         setcookie('password', $_POST['password'], time() + 3600*24*30);
      }
      header('Location: '.$success_page);
      exit;
   }
}
$username = isset($_COOKIE['username']) ? $_COOKIE['username'] : '';
$password = isset($_COOKIE['password']) ? $_COOKIE['password'] : '';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title></title>
<meta name="author" content="Pirvate Untherthered">
<meta name="robots" content="NOINDEX, NOFOLLOW">
<link href="Sans.css" rel="stylesheet" type="text/css">
<link href="lgn.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="space"><br></div>
<div id="container">
<div id="wb_Shape2" style="position:absolute;left:6px;top:4px;width:982px;height:566px;z-index:0;">
<img src="images/img0007.png" id="Shape2" alt="" style="width:982px;height:566px;"></div>
<div id="wb_Image1" style="position:absolute;left:345px;top:54px;width:;height:;z-index:1;">
<img src="images/logo.png" id="Image1" alt=""></div>
<div id="wb_Login1" style="position:absolute;left:338px;top:185px;width:268px;height:130px;text-align:right;z-index:2;">
<form name="loginform" method="post" action="<?php echo basename(__FILE__); ?>" id="loginform">
<input type="hidden" name="form_name" value="loginform">
<table id="Login1">
<tr>
   <td class="Login1_header" colspan="2" style="height:20px;">ACCÈS AUX COMPTES</td>
</tr>
<tr>
   <td style="height:20px;width:127px">Identifiant Client :</td>
   <td style="text-align:left"><input class="Login1_input" name="username" type="text" id="username" value="<?php echo $username; ?>"></td>
</tr>
<tr>
   <td style="height:20px">Mot de passe :</td>
   <td style="text-align:left"><input class="Login1_input" name="password" type="password" id="password" value="<?php echo $password; ?>"></td>
</tr>
<tr>
   <td>&nbsp;</td><td style="text-align:left;height:20px"><input id="rememberme" type="checkbox" name="rememberme">Se souvenir</td>
</tr>
<tr>
   <td>&nbsp;</td><td style="text-align:left;vertical-align:bottom"><input class="Login1_button" type="submit" name="login" value="Accéder" id="login"></td>
</tr>
</table>
</form>
</div>
</div>
</body>
</html>