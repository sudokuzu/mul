<?php

/* HEURE  */
date_default_timezone_set('UTC');
$matin = "Bonjour";
$soir = "Bonsoir";
$nuit = "Bonne soirée";

/* ulgn=1 */
$nom = "M. JÉROME GUERY";
$solde = "+2 180 050€";
$info_u1 = "Votre compte est restreint !";
$conseiller = "M. Claude André";
$numconseiller_u1 = "";
$iban_u1 = "";
$tunetransf_u1 = "";
$benftrsf_u1 = "";
$codebank_u1 = "";
$statrsf_u1 = "";


/* ulgn=2 */
$loadmsgu2 = "Bienvenue votre compte a été bloqué";
$nom_u2 = "Mme. Stalmans Anne";
$solde_u2 = "+25 070,00 €";
$info_u2 = "Votre compte a été bloqué!";
$conseiller_u2 = "M. Frédéric drapeaux";
$numconseiller_u2 = "";
$iban_u2 = "";
$tunetransf_u2 = "";
$benftrsf_u2 = "";
$codebank_u2 = "";
$statrsf_u2 = "Virement en attente";
	   
 /* ulgn=3 */
 
$nom_u3 = "Mme Rose Thibault";
$solde_u3 = "+ 913 000€";
$info_u3 = "Votre compte a été bloqué cliquez ici pour en savoir plus";
$conseiller_u3 = "M. Clothilde";
$numconseiller_u3 = "07 23 70 XX XX";
$iban_u3 = "UK80 30076041571308880030055";
$tunetransf_u3 = "€ 7000 000 EUR";
$benftrsf_u3 = "M. Damien Eric";
$codebank_u3 = "80070";
$statrsf_u3 = "Virement en cours";
	 
?>