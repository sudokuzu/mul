<?php
include('../inc/confu1.php');
/* 
if (session_id() == "")
{
   session_start();
}
if (!isset($_SESSION['username']))
{
   header('Location: ./../access_deny.php');
   exit;
}
if (isset($_SESSION['expires_by']))
{
   $expires_by = intval($_SESSION['expires_by']);
   if (time() < $expires_by)
   {
      $_SESSION['expires_by'] = time() + intval($_SESSION['expires_timeout']);
   }
   else
   {
      unset($_SESSION['username']);
      unset($_SESSION['expires_by']);
      unset($_SESSION['expires_timeout']);
      header('Location: ./../access_deny.php');
      exit;
   }
}
*/
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Banque et assurance</title>
<meta name="author" content="Pirvate Untherthered">
<meta name="robots" content="NOINDEX, NOFOLLOW">
<link href="Sans.css" rel="stylesheet" type="text/css">
<link href="stats.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="space"><br></div>
<div id="container">
<div id="wb_Shape1" style="position:absolute;left:0px;top:116px;width:414px;height:179px;z-index:0;">
<img src="images/img0113.png" id="Shape1" alt="" style="width:414px;height:179px;"></div>
<div id="wb_Text10" style="position:absolute;left:60px;top:77px;width:298px;height:23px;z-index:2;text-align:left;">
<span style="color:#DC143C;font-family:Arial;font-size:20px;">STATUT DE VOTRE VIREMENT</span></div>
<div id="wb_Text1" style="position:absolute;left:11px;top:125px;width:250px;height:16px;z-index:3;text-align:left;">
<span style="color:#DC143C;font-family:Arial;font-size:13px;"><strong>NUMERO IBAN</strong></span></div>
<div id="wb_Text2" style="position:absolute;left:8px;top:154px;width:253px;height:16px;z-index:4;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>
<?php
echo $iban_u1;
?>
</strong></span></div>
<div id="wb_Text3" style="position:absolute;left:268px;top:125px;width:121px;height:16px;z-index:5;text-align:left;">
<span style="color:#DC143C;font-family:Arial;font-size:13px;"><strong>CODE BANQUE</strong></span></div>
<div id="wb_Text4" style="position:absolute;left:290px;top:154px;width:49px;height:16px;z-index:6;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">
<strong>
<?php
echo $codebank_u1;
?>
</strong>
</span></div>
<div id="wb_Text5" style="position:absolute;left:10px;top:182px;width:250px;height:16px;z-index:7;text-align:left;">
<span style="color:#DC143C;font-family:Arial;font-size:13px;"><strong>MONTANT TRANSFERE</strong></span></div>
<div id="wb_Text6" style="position:absolute;left:21px;top:207px;width:146px;height:16px;z-index:8;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">
<strong>
<?php
echo $tunetransf_u1;
?>
</strong>
</span></div>
<div id="wb_Text7" style="position:absolute;left:244px;top:182px;width:250px;height:16px;z-index:9;text-align:left;">
<span style="color:#DC143C;font-family:Arial;font-size:13px;"><strong>Bénéficiaire du virement</strong></span></div>
<div id="wb_Text8" style="position:absolute;left:244px;top:207px;width:250px;height:16px;z-index:10;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">
<strong>
<?php
echo $benftrsf_u1;
?>
</strong>
</span></div>
<div id="wb_Text9" style="position:absolute;left:181px;top:241px;width:59px;height:16px;z-index:11;text-align:left;">
<span style="color:#DC143C;font-family:Arial;font-size:13px;"><strong>STATUT</strong></span></div>
<div id="wb_Text11" style="position:absolute;left:153px;top:257px;width:112px;height:16px;z-index:12;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">
<?php echo $statrsf_u1 ?>
</span></div>
<div id="wb_Image2" style="position:absolute;left:156px;top:271px;width:92px;height:22px;z-index:13;">
<img src="images/progress_bar.gif" id="Image2" alt=""></div>
</div>
</body>
</html>